﻿namespace SYD_COPY_FILE
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.pictureBox_interface = new System.Windows.Forms.PictureBox();
            this.checkBox_synccopy = new System.Windows.Forms.CheckBox();
            this.label_copy_time = new System.Windows.Forms.Label();
            this.pictureBox_lock = new System.Windows.Forms.PictureBox();
            this.label_nowtime = new System.Windows.Forms.Label();
            this.source_copyfile_button = new System.Windows.Forms.Button();
            this.destination_file_button = new System.Windows.Forms.Button();
            this.button_copy_sourcefile_all = new System.Windows.Forms.Button();
            this.source_copyfile_textBox = new System.Windows.Forms.TextBox();
            this.button_copy_destinationfile = new System.Windows.Forms.Button();
            this.destination_file_textBox = new System.Windows.Forms.TextBox();
            this.button_copy_sourcefile = new System.Windows.Forms.Button();
            this.destination_file_textBox_two = new System.Windows.Forms.TextBox();
            this.textBox_copy_destinationfileend = new System.Windows.Forms.TextBox();
            this.destination_file_button_copy_sourcefile = new System.Windows.Forms.Button();
            this.button_copy_destinationfileend = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.destination_file_button_sync = new System.Windows.Forms.Button();
            this.comboBox_Common_path = new System.Windows.Forms.ComboBox();
            this.source_copyfile_textBox_sync_checksum = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.source_copyfile_textBox_sync_size = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.checkBox_synccopy_sync = new System.Windows.Forms.CheckBox();
            this.source_copyfile_button_sync = new System.Windows.Forms.Button();
            this.source_copyfile_textBox_sync = new System.Windows.Forms.TextBox();
            this.destination_file_textBox_sync = new System.Windows.Forms.TextBox();
            this.destination_file_textBox_two_sync = new System.Windows.Forms.TextBox();
            this.textBox_copy_destinationfileend_sync = new System.Windows.Forms.TextBox();
            this.destination_file_button_copy_sourcefile_sync = new System.Windows.Forms.Button();
            this.button_copy_destinationfileend_sync = new System.Windows.Forms.Button();
            this.button_copy_sourcefile_all_sync = new System.Windows.Forms.Button();
            this.button_copy_destinationfile_sync = new System.Windows.Forms.Button();
            this.button_copy_sourcefile_sync = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox_systemtime_rename = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.comboBox_timetype_rename = new System.Windows.Forms.ComboBox();
            this.button_copy_sourcefile4 = new System.Windows.Forms.Button();
            this.destination_file_button_generate_rename = new System.Windows.Forms.Button();
            this.source_copyfile_suffix_textBox_rename = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.source_copyfile_prefix_textBox_rename = new System.Windows.Forms.TextBox();
            this.source_copyfile_button_rename = new System.Windows.Forms.Button();
            this.source_copyfile_textBox_rename = new System.Windows.Forms.TextBox();
            this.destination_file_textBox_rename = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.button_copy_sourcefile5 = new System.Windows.Forms.Button();
            this.button_splitbinfile = new System.Windows.Forms.Button();
            this.textBox_splitbinfile = new System.Windows.Forms.TextBox();
            this.textBox_section1 = new System.Windows.Forms.TextBox();
            this.comboBox_splittype = new System.Windows.Forms.ComboBox();
            this.textBox_sectionout6 = new System.Windows.Forms.TextBox();
            this.textBox_sectionout5 = new System.Windows.Forms.TextBox();
            this.textBox_sectionout4 = new System.Windows.Forms.TextBox();
            this.textBox_sectionout3 = new System.Windows.Forms.TextBox();
            this.textBox_sectionout2 = new System.Windows.Forms.TextBox();
            this.textBox_sectionout1 = new System.Windows.Forms.TextBox();
            this.button_split = new System.Windows.Forms.Button();
            this.textBox_section5 = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.textBox_section4 = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.textBox_section3 = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.textBox_section2 = new System.Windows.Forms.TextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button_sectionintput6 = new System.Windows.Forms.Button();
            this.textBox_sectionintput6 = new System.Windows.Forms.TextBox();
            this.button_sectionintput1 = new System.Windows.Forms.Button();
            this.button_sectionintput5 = new System.Windows.Forms.Button();
            this.textBox_sectionintput1 = new System.Windows.Forms.TextBox();
            this.textBox_sectionintput5 = new System.Windows.Forms.TextBox();
            this.button_sectionintput2 = new System.Windows.Forms.Button();
            this.button_sectionintput4 = new System.Windows.Forms.Button();
            this.textBox_sectionintput2 = new System.Windows.Forms.TextBox();
            this.textBox_sectionintput4 = new System.Windows.Forms.TextBox();
            this.button_sectionintput3 = new System.Windows.Forms.Button();
            this.textBox_sectionintput3 = new System.Windows.Forms.TextBox();
            this.label_nowtime1 = new System.Windows.Forms.Label();
            this.button_combine = new System.Windows.Forms.Button();
            this.label_nowtime2 = new System.Windows.Forms.Label();
            this.label_nowtime4 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label_nowtime3 = new System.Windows.Forms.Label();
            this.label_nowtime0 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label65 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.LED_Display = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.textBoxy1 = new System.Windows.Forms.TextBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.textBoxx1 = new System.Windows.Forms.TextBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox_Num8 = new System.Windows.Forms.TextBox();
            this.button_font8 = new System.Windows.Forms.Button();
            this.textBox_Num7 = new System.Windows.Forms.TextBox();
            this.textBox_Hight8 = new System.Windows.Forms.TextBox();
            this.textBox_Num6 = new System.Windows.Forms.TextBox();
            this.textBox_Num5 = new System.Windows.Forms.TextBox();
            this.textBox_Width8 = new System.Windows.Forms.TextBox();
            this.textBox_Num4 = new System.Windows.Forms.TextBox();
            this.button_font7 = new System.Windows.Forms.Button();
            this.textBox_Num3 = new System.Windows.Forms.TextBox();
            this.textBox_Hight7 = new System.Windows.Forms.TextBox();
            this.textBox_Num2 = new System.Windows.Forms.TextBox();
            this.textBox_Width7 = new System.Windows.Forms.TextBox();
            this.textBox_Num1 = new System.Windows.Forms.TextBox();
            this.button_font6 = new System.Windows.Forms.Button();
            this.textBox_Hight6 = new System.Windows.Forms.TextBox();
            this.textBox_Width6 = new System.Windows.Forms.TextBox();
            this.button_font5 = new System.Windows.Forms.Button();
            this.textBox_Hight5 = new System.Windows.Forms.TextBox();
            this.textBox_Width5 = new System.Windows.Forms.TextBox();
            this.button_font4 = new System.Windows.Forms.Button();
            this.textBox_Hight4 = new System.Windows.Forms.TextBox();
            this.textBox_Width4 = new System.Windows.Forms.TextBox();
            this.button_font3 = new System.Windows.Forms.Button();
            this.textBox_Hight3 = new System.Windows.Forms.TextBox();
            this.textBox_Width3 = new System.Windows.Forms.TextBox();
            this.button_font2 = new System.Windows.Forms.Button();
            this.textBox_Hight2 = new System.Windows.Forms.TextBox();
            this.textBox_Width2 = new System.Windows.Forms.TextBox();
            this.button_font1 = new System.Windows.Forms.Button();
            this.textBox_Hight1 = new System.Windows.Forms.TextBox();
            this.textBox_Width1 = new System.Windows.Forms.TextBox();
            this.textBox_outsideh = new System.Windows.Forms.TextBox();
            this.textBox_outsidew = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_insideRw = new System.Windows.Forms.TextBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.textBox_insideRh = new System.Windows.Forms.TextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.button21 = new System.Windows.Forms.Button();
            this.textBox_insideh = new System.Windows.Forms.TextBox();
            this.textBox_insidew = new System.Windows.Forms.TextBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label50 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBoxR = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBoxB = new System.Windows.Forms.TextBox();
            this.buttonRGB = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.textBoxG = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.LED_result1_textBox = new System.Windows.Forms.TextBox();
            this.LED_input1_textBox = new System.Windows.Forms.TextBox();
            this.label_turn1 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox_GPIO7 = new System.Windows.Forms.TextBox();
            this.textBox_GPIO6 = new System.Windows.Forms.TextBox();
            this.textBox_GPIO5 = new System.Windows.Forms.TextBox();
            this.textBox_GPIO4 = new System.Windows.Forms.TextBox();
            this.textBox_GPIO3 = new System.Windows.Forms.TextBox();
            this.textBox_GPIO2 = new System.Windows.Forms.TextBox();
            this.textBox_GPIO1 = new System.Windows.Forms.TextBox();
            this.textBox_GPIO0 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.BIT_MARK8 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK11 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK10 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK9 = new System.Windows.Forms.CheckBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.BIT_MARK4 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK7 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK6 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK5 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BIT_MARK28 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK31 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK30 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK29 = new System.Windows.Forms.CheckBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.BIT_MARK0 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK3 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK2 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK1 = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BIT_MARK27 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK26 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK25 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK24 = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BIT_MARK12 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK15 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK14 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK13 = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.BIT_MARK16 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK19 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK18 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK17 = new System.Windows.Forms.CheckBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.BIT_MARK23 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK22 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK21 = new System.Windows.Forms.CheckBox();
            this.BIT_MARK20 = new System.Windows.Forms.CheckBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.button17 = new System.Windows.Forms.Button();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.bit_mask_result = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.button29 = new System.Windows.Forms.Button();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.button28 = new System.Windows.Forms.Button();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button30 = new System.Windows.Forms.Button();
            this.label84 = new System.Windows.Forms.Label();
            this.comboBox_mode = new System.Windows.Forms.ComboBox();
            this.button_clear = new System.Windows.Forms.Button();
            this.draw = new System.Windows.Forms.Button();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.richTextBox_out = new System.Windows.Forms.RichTextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.textInput = new System.Windows.Forms.RichTextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.comboBox_fonttype = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.comboBox_datatype = new System.Windows.Forms.ComboBox();
            this.label78 = new System.Windows.Forms.Label();
            this.textBox_filesize = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label_intputsize = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label_outfilename = new System.Windows.Forms.Label();
            this.source_file_button = new System.Windows.Forms.Button();
            this.label83 = new System.Windows.Forms.Label();
            this.source_file_textBox = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.timer.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_interface)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_lock)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel16.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.LED_Display.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(573, 71);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "32768_timer_cal";
            // 
            // textBox9
            // 
            this.textBox9.AllowDrop = true;
            this.textBox9.Location = new System.Drawing.Point(499, 42);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(68, 21);
            this.textBox9.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(238, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 24;
            this.label1.Text = "dec:";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/"});
            this.comboBox3.Location = new System.Drawing.Point(257, 14);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(39, 20);
            this.comboBox3.TabIndex = 23;
            this.comboBox3.Text = " ";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/"});
            this.comboBox4.Location = new System.Drawing.Point(196, 40);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(41, 20);
            this.comboBox4.TabIndex = 22;
            this.comboBox4.Text = " ";
            // 
            // textBox1
            // 
            this.textBox1.AllowDrop = true;
            this.textBox1.Location = new System.Drawing.Point(299, 13);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(91, 21);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "1000/32768";
            // 
            // textBox2
            // 
            this.textBox2.AllowDrop = true;
            this.textBox2.Location = new System.Drawing.Point(269, 41);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(91, 21);
            this.textBox2.TabIndex = 21;
            this.textBox2.Text = "1000/32768";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/"});
            this.comboBox2.Location = new System.Drawing.Point(129, 14);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(41, 20);
            this.comboBox2.TabIndex = 19;
            this.comboBox2.Tag = "";
            this.comboBox2.Text = " ";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/"});
            this.comboBox1.Location = new System.Drawing.Point(95, 40);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(43, 20);
            this.comboBox1.TabIndex = 18;
            this.comboBox1.Text = " ";
            // 
            // textBox6
            // 
            this.textBox6.AllowDrop = true;
            this.textBox6.Location = new System.Drawing.Point(35, 13);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(92, 21);
            this.textBox6.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(393, 11);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(53, 22);
            this.button2.TabIndex = 0;
            this.button2.Text = "cal";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox7
            // 
            this.textBox7.AllowDrop = true;
            this.textBox7.Location = new System.Drawing.Point(449, 12);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(118, 21);
            this.textBox7.TabIndex = 9;
            // 
            // textBox3
            // 
            this.textBox3.AllowDrop = true;
            this.textBox3.Location = new System.Drawing.Point(35, 40);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(54, 21);
            this.textBox3.TabIndex = 2;
            this.textBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_KeyDown);
            // 
            // textBox8
            // 
            this.textBox8.AllowDrop = true;
            this.textBox8.Location = new System.Drawing.Point(168, 13);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(89, 21);
            this.textBox8.TabIndex = 10;
            this.textBox8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox8_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "dec:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(366, 40);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(53, 22);
            this.button1.TabIndex = 0;
            this.button1.Text = "cal";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox4
            // 
            this.textBox4.AllowDrop = true;
            this.textBox4.Location = new System.Drawing.Point(425, 41);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(68, 21);
            this.textBox4.TabIndex = 9;
            // 
            // textBox5
            // 
            this.textBox5.AllowDrop = true;
            this.textBox5.Location = new System.Drawing.Point(136, 40);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(54, 21);
            this.textBox5.TabIndex = 10;
            this.textBox5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "hex:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox60);
            this.groupBox3.Controls.Add(this.textBox57);
            this.groupBox3.Controls.Add(this.textBox56);
            this.groupBox3.Controls.Add(this.textBox30);
            this.groupBox3.Controls.Add(this.textBox26);
            this.groupBox3.Controls.Add(this.textBox34);
            this.groupBox3.Controls.Add(this.textBox27);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.textBox38);
            this.groupBox3.Controls.Add(this.textBox28);
            this.groupBox3.Controls.Add(this.textBox39);
            this.groupBox3.Controls.Add(this.textBox29);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.button11);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Controls.Add(this.textBox25);
            this.groupBox3.Controls.Add(this.textBox23);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.textBox22);
            this.groupBox3.Controls.Add(this.textBox21);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Location = new System.Drawing.Point(3, 72);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(663, 102);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " Calendar Time Difference(18:05:55:386)";
            // 
            // textBox60
            // 
            this.textBox60.AllowDrop = true;
            this.textBox60.Location = new System.Drawing.Point(575, 73);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(82, 21);
            this.textBox60.TabIndex = 46;
            // 
            // textBox57
            // 
            this.textBox57.AllowDrop = true;
            this.textBox57.Location = new System.Drawing.Point(575, 43);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(82, 21);
            this.textBox57.TabIndex = 45;
            // 
            // textBox56
            // 
            this.textBox56.AllowDrop = true;
            this.textBox56.Location = new System.Drawing.Point(575, 17);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(82, 21);
            this.textBox56.TabIndex = 44;
            // 
            // textBox30
            // 
            this.textBox30.AllowDrop = true;
            this.textBox30.Location = new System.Drawing.Point(376, 73);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(32, 21);
            this.textBox30.TabIndex = 43;
            this.textBox30.Text = "0";
            // 
            // textBox26
            // 
            this.textBox26.AllowDrop = true;
            this.textBox26.Location = new System.Drawing.Point(376, 43);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(32, 21);
            this.textBox26.TabIndex = 35;
            this.textBox26.Text = "0";
            // 
            // textBox34
            // 
            this.textBox34.AllowDrop = true;
            this.textBox34.Location = new System.Drawing.Point(470, 73);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 21);
            this.textBox34.TabIndex = 41;
            // 
            // textBox27
            // 
            this.textBox27.AllowDrop = true;
            this.textBox27.Location = new System.Drawing.Point(470, 43);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 21);
            this.textBox27.TabIndex = 33;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(352, 78);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 42;
            this.label20.Text = "Day:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(352, 48);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 34;
            this.label17.Text = "Day:";
            // 
            // textBox38
            // 
            this.textBox38.AllowDrop = true;
            this.textBox38.Location = new System.Drawing.Point(251, 73);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 21);
            this.textBox38.TabIndex = 40;
            this.textBox38.Text = "18:05:24:101";
            // 
            // textBox28
            // 
            this.textBox28.AllowDrop = true;
            this.textBox28.Location = new System.Drawing.Point(251, 43);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 21);
            this.textBox28.TabIndex = 32;
            this.textBox28.Text = "22:52:24.529520";
            // 
            // textBox39
            // 
            this.textBox39.AllowDrop = true;
            this.textBox39.Location = new System.Drawing.Point(61, 75);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(109, 21);
            this.textBox39.TabIndex = 38;
            this.textBox39.Text = "18:05:59:505";
            // 
            // textBox29
            // 
            this.textBox29.AllowDrop = true;
            this.textBox29.Location = new System.Drawing.Point(61, 45);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(109, 21);
            this.textBox29.TabIndex = 30;
            this.textBox29.Text = "22:52:27.252726";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(4, 78);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 12);
            this.label23.TabIndex = 39;
            this.label23.Text = "Now Time:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(172, 80);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 12);
            this.label26.TabIndex = 37;
            this.label26.Text = "Before Time:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(4, 48);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 12);
            this.label18.TabIndex = 31;
            this.label18.Text = "Now Time:";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(411, 73);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(53, 22);
            this.button11.TabIndex = 36;
            this.button11.Text = "cal";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(172, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 12);
            this.label19.TabIndex = 29;
            this.label19.Text = "Before Time:";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(411, 43);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(53, 22);
            this.button8.TabIndex = 28;
            this.button8.Text = "cal";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox25
            // 
            this.textBox25.AllowDrop = true;
            this.textBox25.Location = new System.Drawing.Point(376, 16);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(32, 21);
            this.textBox25.TabIndex = 27;
            this.textBox25.Text = "0";
            // 
            // textBox23
            // 
            this.textBox23.AllowDrop = true;
            this.textBox23.Location = new System.Drawing.Point(470, 16);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 21);
            this.textBox23.TabIndex = 26;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(352, 21);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 26;
            this.label16.Text = "Day:";
            // 
            // textBox22
            // 
            this.textBox22.AllowDrop = true;
            this.textBox22.Location = new System.Drawing.Point(251, 16);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 21);
            this.textBox22.TabIndex = 25;
            this.textBox22.Text = "18:05:24:101";
            // 
            // textBox21
            // 
            this.textBox21.AllowDrop = true;
            this.textBox21.Location = new System.Drawing.Point(61, 18);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(109, 21);
            this.textBox21.TabIndex = 23;
            this.textBox21.Text = "18:05:59:505";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 24;
            this.label14.Text = "Now Time:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(172, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(77, 12);
            this.label15.TabIndex = 22;
            this.label15.Text = "Before Time:";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(411, 16);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(53, 22);
            this.button7.TabIndex = 0;
            this.button7.Text = "cal";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox40);
            this.groupBox5.Controls.Add(this.textBox31);
            this.groupBox5.Controls.Add(this.textBox41);
            this.groupBox5.Controls.Add(this.textBox32);
            this.groupBox5.Controls.Add(this.textBox42);
            this.groupBox5.Controls.Add(this.textBox33);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.button12);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.button9);
            this.groupBox5.Controls.Add(this.textBox35);
            this.groupBox5.Controls.Add(this.textBox36);
            this.groupBox5.Controls.Add(this.textBox37);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.button10);
            this.groupBox5.Location = new System.Drawing.Point(3, 176);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(446, 108);
            this.groupBox5.TabIndex = 23;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "timestamp Difference(0x23120D08)";
            // 
            // textBox40
            // 
            this.textBox40.AllowDrop = true;
            this.textBox40.Location = new System.Drawing.Point(338, 76);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 21);
            this.textBox40.TabIndex = 39;
            // 
            // textBox31
            // 
            this.textBox31.AllowDrop = true;
            this.textBox31.Location = new System.Drawing.Point(338, 45);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(100, 21);
            this.textBox31.TabIndex = 33;
            // 
            // textBox41
            // 
            this.textBox41.AllowDrop = true;
            this.textBox41.Location = new System.Drawing.Point(209, 76);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(68, 21);
            this.textBox41.TabIndex = 38;
            this.textBox41.Text = "0x23120D08";
            // 
            // textBox32
            // 
            this.textBox32.AllowDrop = true;
            this.textBox32.Location = new System.Drawing.Point(209, 47);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(68, 21);
            this.textBox32.TabIndex = 32;
            this.textBox32.Text = "0x23120D08";
            // 
            // textBox42
            // 
            this.textBox42.AllowDrop = true;
            this.textBox42.Location = new System.Drawing.Point(61, 76);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(66, 21);
            this.textBox42.TabIndex = 36;
            this.textBox42.Text = "0x23128560";
            // 
            // textBox33
            // 
            this.textBox33.AllowDrop = true;
            this.textBox33.Location = new System.Drawing.Point(61, 47);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(66, 21);
            this.textBox33.TabIndex = 30;
            this.textBox33.Text = "0x23128560";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(4, 79);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 12);
            this.label27.TabIndex = 37;
            this.label27.Text = "Now Time:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(130, 81);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(77, 12);
            this.label28.TabIndex = 35;
            this.label28.Text = "Before Time:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(4, 48);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 12);
            this.label21.TabIndex = 31;
            this.label21.Text = "Now Time:";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(279, 76);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(53, 22);
            this.button12.TabIndex = 34;
            this.button12.Text = "cal";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(130, 50);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(77, 12);
            this.label22.TabIndex = 29;
            this.label22.Text = "Before Time:";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(279, 45);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(53, 22);
            this.button9.TabIndex = 28;
            this.button9.Text = "cal";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox35
            // 
            this.textBox35.AllowDrop = true;
            this.textBox35.Location = new System.Drawing.Point(338, 18);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 21);
            this.textBox35.TabIndex = 26;
            // 
            // textBox36
            // 
            this.textBox36.AllowDrop = true;
            this.textBox36.Location = new System.Drawing.Point(209, 18);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(68, 21);
            this.textBox36.TabIndex = 25;
            this.textBox36.Text = "0x23120D08";
            // 
            // textBox37
            // 
            this.textBox37.AllowDrop = true;
            this.textBox37.Location = new System.Drawing.Point(61, 18);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(66, 21);
            this.textBox37.TabIndex = 23;
            this.textBox37.Text = "0x23128560";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(4, 21);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 12);
            this.label24.TabIndex = 24;
            this.label24.Text = "Now Time:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(130, 23);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 22;
            this.label25.Text = "Before Time:";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(279, 18);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(53, 22);
            this.button10.TabIndex = 0;
            this.button10.Text = "cal";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // timer
            // 
            this.timer.Controls.Add(this.tabPage5);
            this.timer.Controls.Add(this.tabPage6);
            this.timer.Controls.Add(this.tabPage7);
            this.timer.Controls.Add(this.tabPage8);
            this.timer.Controls.Add(this.tabPage9);
            this.timer.Controls.Add(this.tabPage1);
            this.timer.Controls.Add(this.LED_Display);
            this.timer.Controls.Add(this.tabPage2);
            this.timer.Controls.Add(this.tabPage3);
            this.timer.Controls.Add(this.tabPage4);
            this.timer.Location = new System.Drawing.Point(1, 1);
            this.timer.Name = "timer";
            this.timer.SelectedIndex = 0;
            this.timer.Size = new System.Drawing.Size(765, 578);
            this.timer.TabIndex = 24;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.pictureBox_interface);
            this.tabPage5.Controls.Add(this.checkBox_synccopy);
            this.tabPage5.Controls.Add(this.label_copy_time);
            this.tabPage5.Controls.Add(this.pictureBox_lock);
            this.tabPage5.Controls.Add(this.label_nowtime);
            this.tabPage5.Controls.Add(this.source_copyfile_button);
            this.tabPage5.Controls.Add(this.destination_file_button);
            this.tabPage5.Controls.Add(this.button_copy_sourcefile_all);
            this.tabPage5.Controls.Add(this.source_copyfile_textBox);
            this.tabPage5.Controls.Add(this.button_copy_destinationfile);
            this.tabPage5.Controls.Add(this.destination_file_textBox);
            this.tabPage5.Controls.Add(this.button_copy_sourcefile);
            this.tabPage5.Controls.Add(this.destination_file_textBox_two);
            this.tabPage5.Controls.Add(this.textBox_copy_destinationfileend);
            this.tabPage5.Controls.Add(this.destination_file_button_copy_sourcefile);
            this.tabPage5.Controls.Add(this.button_copy_destinationfileend);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(757, 552);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Cpye";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // pictureBox_interface
            // 
            this.pictureBox_interface.Image = global::SYD_COPY_FILE.Properties.Resources.min;
            this.pictureBox_interface.Location = new System.Drawing.Point(35, 34);
            this.pictureBox_interface.Name = "pictureBox_interface";
            this.pictureBox_interface.Size = new System.Drawing.Size(35, 35);
            this.pictureBox_interface.TabIndex = 38;
            this.pictureBox_interface.TabStop = false;
            this.pictureBox_interface.Click += new System.EventHandler(this.pictureBoxinterface_Click);
            // 
            // checkBox_synccopy
            // 
            this.checkBox_synccopy.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox_synccopy.Location = new System.Drawing.Point(402, 35);
            this.checkBox_synccopy.Name = "checkBox_synccopy";
            this.checkBox_synccopy.Size = new System.Drawing.Size(61, 31);
            this.checkBox_synccopy.TabIndex = 36;
            this.checkBox_synccopy.Text = "同步拷贝";
            this.checkBox_synccopy.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.checkBox_synccopy.UseVisualStyleBackColor = true;
            this.checkBox_synccopy.CheckedChanged += new System.EventHandler(this.checkBox_synccopy_sync_CheckedChanged);
            // 
            // label_copy_time
            // 
            this.label_copy_time.Font = new System.Drawing.Font("宋体", 9F);
            this.label_copy_time.Location = new System.Drawing.Point(3, 131);
            this.label_copy_time.Name = "label_copy_time";
            this.label_copy_time.Size = new System.Drawing.Size(460, 15);
            this.label_copy_time.TabIndex = 37;
            this.label_copy_time.Text = "label91";
            // 
            // pictureBox_lock
            // 
            this.pictureBox_lock.Image = global::SYD_COPY_FILE.Properties.Resources.unlock;
            this.pictureBox_lock.Location = new System.Drawing.Point(4, 34);
            this.pictureBox_lock.Name = "pictureBox_lock";
            this.pictureBox_lock.Size = new System.Drawing.Size(29, 35);
            this.pictureBox_lock.TabIndex = 29;
            this.pictureBox_lock.TabStop = false;
            this.pictureBox_lock.Click += new System.EventHandler(this.lock_button_Click);
            // 
            // label_nowtime
            // 
            this.label_nowtime.Font = new System.Drawing.Font("宋体", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_nowtime.Location = new System.Drawing.Point(71, 32);
            this.label_nowtime.Name = "label_nowtime";
            this.label_nowtime.Size = new System.Drawing.Size(358, 35);
            this.label_nowtime.TabIndex = 35;
            this.label_nowtime.Text = "label_nowtime";
            // 
            // source_copyfile_button
            // 
            this.source_copyfile_button.Location = new System.Drawing.Point(467, 1);
            this.source_copyfile_button.Name = "source_copyfile_button";
            this.source_copyfile_button.Size = new System.Drawing.Size(125, 22);
            this.source_copyfile_button.TabIndex = 23;
            this.source_copyfile_button.Text = "source file";
            this.source_copyfile_button.UseVisualStyleBackColor = true;
            this.source_copyfile_button.Click += new System.EventHandler(this.source_copyfile_button_Click);
            // 
            // destination_file_button
            // 
            this.destination_file_button.Location = new System.Drawing.Point(352, 72);
            this.destination_file_button.Name = "destination_file_button";
            this.destination_file_button.Size = new System.Drawing.Size(176, 25);
            this.destination_file_button.TabIndex = 24;
            this.destination_file_button.Text = "destination file";
            this.destination_file_button.UseVisualStyleBackColor = true;
            this.destination_file_button.Click += new System.EventHandler(this.destination_file_button_Click);
            // 
            // button_copy_sourcefile_all
            // 
            this.button_copy_sourcefile_all.Image = global::SYD_COPY_FILE.Properties.Resources.arrows45X200;
            this.button_copy_sourcefile_all.Location = new System.Drawing.Point(534, 23);
            this.button_copy_sourcefile_all.Name = "button_copy_sourcefile_all";
            this.button_copy_sourcefile_all.Size = new System.Drawing.Size(48, 116);
            this.button_copy_sourcefile_all.TabIndex = 34;
            this.button_copy_sourcefile_all.UseVisualStyleBackColor = true;
            this.button_copy_sourcefile_all.Click += new System.EventHandler(this.button_copy_sourcefile_all_Click);
            // 
            // source_copyfile_textBox
            // 
            this.source_copyfile_textBox.AllowDrop = true;
            this.source_copyfile_textBox.Location = new System.Drawing.Point(0, 3);
            this.source_copyfile_textBox.Name = "source_copyfile_textBox";
            this.source_copyfile_textBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.source_copyfile_textBox.Size = new System.Drawing.Size(454, 21);
            this.source_copyfile_textBox.TabIndex = 25;
            this.source_copyfile_textBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.source_copyfile_textBox.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // button_copy_destinationfile
            // 
            this.button_copy_destinationfile.Image = global::SYD_COPY_FILE.Properties.Resources.arrows45X50;
            this.button_copy_destinationfile.Location = new System.Drawing.Point(480, 95);
            this.button_copy_destinationfile.Name = "button_copy_destinationfile";
            this.button_copy_destinationfile.Size = new System.Drawing.Size(48, 44);
            this.button_copy_destinationfile.TabIndex = 33;
            this.button_copy_destinationfile.UseVisualStyleBackColor = true;
            this.button_copy_destinationfile.Click += new System.EventHandler(this.button_copy_destinationfile_Click);
            // 
            // destination_file_textBox
            // 
            this.destination_file_textBox.AllowDrop = true;
            this.destination_file_textBox.Location = new System.Drawing.Point(0, 76);
            this.destination_file_textBox.Name = "destination_file_textBox";
            this.destination_file_textBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.destination_file_textBox.Size = new System.Drawing.Size(346, 21);
            this.destination_file_textBox.TabIndex = 26;
            this.destination_file_textBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.destination_file_textBox.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // button_copy_sourcefile
            // 
            this.button_copy_sourcefile.Image = global::SYD_COPY_FILE.Properties.Resources.arrows45X50;
            this.button_copy_sourcefile.Location = new System.Drawing.Point(467, 28);
            this.button_copy_sourcefile.Name = "button_copy_sourcefile";
            this.button_copy_sourcefile.Size = new System.Drawing.Size(48, 44);
            this.button_copy_sourcefile.TabIndex = 32;
            this.button_copy_sourcefile.UseVisualStyleBackColor = true;
            this.button_copy_sourcefile.Click += new System.EventHandler(this.copy_button_Click);
            // 
            // destination_file_textBox_two
            // 
            this.destination_file_textBox_two.AllowDrop = true;
            this.destination_file_textBox_two.Location = new System.Drawing.Point(0, 106);
            this.destination_file_textBox_two.Name = "destination_file_textBox_two";
            this.destination_file_textBox_two.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.destination_file_textBox_two.Size = new System.Drawing.Size(346, 21);
            this.destination_file_textBox_two.TabIndex = 27;
            this.destination_file_textBox_two.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.destination_file_textBox_two.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // textBox_copy_destinationfileend
            // 
            this.textBox_copy_destinationfileend.AllowDrop = true;
            this.textBox_copy_destinationfileend.Location = new System.Drawing.Point(0, 146);
            this.textBox_copy_destinationfileend.Name = "textBox_copy_destinationfileend";
            this.textBox_copy_destinationfileend.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox_copy_destinationfileend.Size = new System.Drawing.Size(461, 21);
            this.textBox_copy_destinationfileend.TabIndex = 31;
            this.textBox_copy_destinationfileend.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.textBox_copy_destinationfileend.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // destination_file_button_copy_sourcefile
            // 
            this.destination_file_button_copy_sourcefile.Location = new System.Drawing.Point(352, 103);
            this.destination_file_button_copy_sourcefile.Name = "destination_file_button_copy_sourcefile";
            this.destination_file_button_copy_sourcefile.Size = new System.Drawing.Size(123, 25);
            this.destination_file_button_copy_sourcefile.TabIndex = 28;
            this.destination_file_button_copy_sourcefile.Text = "destination file";
            this.destination_file_button_copy_sourcefile.UseVisualStyleBackColor = true;
            this.destination_file_button_copy_sourcefile.Click += new System.EventHandler(this.source_copyfile_button_Click);
            // 
            // button_copy_destinationfileend
            // 
            this.button_copy_destinationfileend.Location = new System.Drawing.Point(469, 143);
            this.button_copy_destinationfileend.Name = "button_copy_destinationfileend";
            this.button_copy_destinationfileend.Size = new System.Drawing.Size(123, 25);
            this.button_copy_destinationfileend.TabIndex = 30;
            this.button_copy_destinationfileend.Text = "destination file";
            this.button_copy_destinationfileend.UseVisualStyleBackColor = true;
            this.button_copy_destinationfileend.Click += new System.EventHandler(this.source_copyfile_button_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.destination_file_button_sync);
            this.tabPage6.Controls.Add(this.comboBox_Common_path);
            this.tabPage6.Controls.Add(this.source_copyfile_textBox_sync_checksum);
            this.tabPage6.Controls.Add(this.label55);
            this.tabPage6.Controls.Add(this.source_copyfile_textBox_sync_size);
            this.tabPage6.Controls.Add(this.label54);
            this.tabPage6.Controls.Add(this.checkBox_synccopy_sync);
            this.tabPage6.Controls.Add(this.source_copyfile_button_sync);
            this.tabPage6.Controls.Add(this.source_copyfile_textBox_sync);
            this.tabPage6.Controls.Add(this.destination_file_textBox_sync);
            this.tabPage6.Controls.Add(this.destination_file_textBox_two_sync);
            this.tabPage6.Controls.Add(this.textBox_copy_destinationfileend_sync);
            this.tabPage6.Controls.Add(this.destination_file_button_copy_sourcefile_sync);
            this.tabPage6.Controls.Add(this.button_copy_destinationfileend_sync);
            this.tabPage6.Controls.Add(this.button_copy_sourcefile_all_sync);
            this.tabPage6.Controls.Add(this.button_copy_destinationfile_sync);
            this.tabPage6.Controls.Add(this.button_copy_sourcefile_sync);
            this.tabPage6.Controls.Add(this.label5);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(757, 552);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Sync copy";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // destination_file_button_sync
            // 
            this.destination_file_button_sync.Location = new System.Drawing.Point(352, 72);
            this.destination_file_button_sync.Name = "destination_file_button_sync";
            this.destination_file_button_sync.Size = new System.Drawing.Size(176, 25);
            this.destination_file_button_sync.TabIndex = 25;
            this.destination_file_button_sync.Text = "destination file";
            this.destination_file_button_sync.UseVisualStyleBackColor = true;
            this.destination_file_button_sync.Click += new System.EventHandler(this.source_copyfile_button_Click);
            // 
            // comboBox_Common_path
            // 
            this.comboBox_Common_path.FormattingEnabled = true;
            this.comboBox_Common_path.Items.AddRange(new object[] {
            "normal",
            "F:\\SYD8801\\Company data\\SYDTEK Studio  release"});
            this.comboBox_Common_path.Location = new System.Drawing.Point(61, 55);
            this.comboBox_Common_path.Name = "comboBox_Common_path";
            this.comboBox_Common_path.Size = new System.Drawing.Size(315, 20);
            this.comboBox_Common_path.TabIndex = 40;
            this.comboBox_Common_path.SelectedIndexChanged += new System.EventHandler(this.comboBox_Common_path_SelectedIndexChanged);
            // 
            // source_copyfile_textBox_sync_checksum
            // 
            this.source_copyfile_textBox_sync_checksum.AllowDrop = true;
            this.source_copyfile_textBox_sync_checksum.Location = new System.Drawing.Point(241, 30);
            this.source_copyfile_textBox_sync_checksum.Name = "source_copyfile_textBox_sync_checksum";
            this.source_copyfile_textBox_sync_checksum.Size = new System.Drawing.Size(135, 21);
            this.source_copyfile_textBox_sync_checksum.TabIndex = 39;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(184, 33);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(59, 12);
            this.label55.TabIndex = 38;
            this.label55.Text = "checksum:";
            // 
            // source_copyfile_textBox_sync_size
            // 
            this.source_copyfile_textBox_sync_size.AllowDrop = true;
            this.source_copyfile_textBox_sync_size.Location = new System.Drawing.Point(36, 30);
            this.source_copyfile_textBox_sync_size.Name = "source_copyfile_textBox_sync_size";
            this.source_copyfile_textBox_sync_size.Size = new System.Drawing.Size(135, 21);
            this.source_copyfile_textBox_sync_size.TabIndex = 37;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(3, 33);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(35, 12);
            this.label54.TabIndex = 36;
            this.label54.Text = "size:";
            // 
            // checkBox_synccopy_sync
            // 
            this.checkBox_synccopy_sync.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.checkBox_synccopy_sync.Location = new System.Drawing.Point(372, 35);
            this.checkBox_synccopy_sync.Name = "checkBox_synccopy_sync";
            this.checkBox_synccopy_sync.Size = new System.Drawing.Size(73, 31);
            this.checkBox_synccopy_sync.TabIndex = 35;
            this.checkBox_synccopy_sync.Text = "同步拷贝";
            this.checkBox_synccopy_sync.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.checkBox_synccopy_sync.UseVisualStyleBackColor = true;
            this.checkBox_synccopy_sync.CheckedChanged += new System.EventHandler(this.checkBox_synccopy_sync_CheckedChanged);
            // 
            // source_copyfile_button_sync
            // 
            this.source_copyfile_button_sync.Location = new System.Drawing.Point(467, 1);
            this.source_copyfile_button_sync.Name = "source_copyfile_button_sync";
            this.source_copyfile_button_sync.Size = new System.Drawing.Size(125, 22);
            this.source_copyfile_button_sync.TabIndex = 24;
            this.source_copyfile_button_sync.Text = "source file";
            this.source_copyfile_button_sync.UseVisualStyleBackColor = true;
            // 
            // source_copyfile_textBox_sync
            // 
            this.source_copyfile_textBox_sync.AllowDrop = true;
            this.source_copyfile_textBox_sync.Location = new System.Drawing.Point(0, 3);
            this.source_copyfile_textBox_sync.Name = "source_copyfile_textBox_sync";
            this.source_copyfile_textBox_sync.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.source_copyfile_textBox_sync.Size = new System.Drawing.Size(454, 21);
            this.source_copyfile_textBox_sync.TabIndex = 26;
            this.source_copyfile_textBox_sync.TextChanged += new System.EventHandler(this.source_copyfile_textBox_sync_TextChanged);
            this.source_copyfile_textBox_sync.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.source_copyfile_textBox_sync.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // destination_file_textBox_sync
            // 
            this.destination_file_textBox_sync.AllowDrop = true;
            this.destination_file_textBox_sync.Location = new System.Drawing.Point(0, 76);
            this.destination_file_textBox_sync.Name = "destination_file_textBox_sync";
            this.destination_file_textBox_sync.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.destination_file_textBox_sync.Size = new System.Drawing.Size(346, 21);
            this.destination_file_textBox_sync.TabIndex = 27;
            this.destination_file_textBox_sync.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.destination_file_textBox_sync.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // destination_file_textBox_two_sync
            // 
            this.destination_file_textBox_two_sync.AllowDrop = true;
            this.destination_file_textBox_two_sync.Location = new System.Drawing.Point(0, 106);
            this.destination_file_textBox_two_sync.Name = "destination_file_textBox_two_sync";
            this.destination_file_textBox_two_sync.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.destination_file_textBox_two_sync.Size = new System.Drawing.Size(346, 21);
            this.destination_file_textBox_two_sync.TabIndex = 28;
            this.destination_file_textBox_two_sync.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.destination_file_textBox_two_sync.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // textBox_copy_destinationfileend_sync
            // 
            this.textBox_copy_destinationfileend_sync.AllowDrop = true;
            this.textBox_copy_destinationfileend_sync.Location = new System.Drawing.Point(0, 146);
            this.textBox_copy_destinationfileend_sync.Name = "textBox_copy_destinationfileend_sync";
            this.textBox_copy_destinationfileend_sync.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBox_copy_destinationfileend_sync.Size = new System.Drawing.Size(461, 21);
            this.textBox_copy_destinationfileend_sync.TabIndex = 31;
            this.textBox_copy_destinationfileend_sync.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.textBox_copy_destinationfileend_sync.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // destination_file_button_copy_sourcefile_sync
            // 
            this.destination_file_button_copy_sourcefile_sync.Location = new System.Drawing.Point(352, 103);
            this.destination_file_button_copy_sourcefile_sync.Name = "destination_file_button_copy_sourcefile_sync";
            this.destination_file_button_copy_sourcefile_sync.Size = new System.Drawing.Size(123, 25);
            this.destination_file_button_copy_sourcefile_sync.TabIndex = 29;
            this.destination_file_button_copy_sourcefile_sync.Text = "destination file";
            this.destination_file_button_copy_sourcefile_sync.UseVisualStyleBackColor = true;
            this.destination_file_button_copy_sourcefile_sync.Click += new System.EventHandler(this.source_copyfile_button_Click);
            // 
            // button_copy_destinationfileend_sync
            // 
            this.button_copy_destinationfileend_sync.Location = new System.Drawing.Point(469, 143);
            this.button_copy_destinationfileend_sync.Name = "button_copy_destinationfileend_sync";
            this.button_copy_destinationfileend_sync.Size = new System.Drawing.Size(123, 25);
            this.button_copy_destinationfileend_sync.TabIndex = 30;
            this.button_copy_destinationfileend_sync.Text = "destination file";
            this.button_copy_destinationfileend_sync.UseVisualStyleBackColor = true;
            this.button_copy_destinationfileend_sync.Click += new System.EventHandler(this.source_copyfile_button_Click);
            // 
            // button_copy_sourcefile_all_sync
            // 
            this.button_copy_sourcefile_all_sync.Image = global::SYD_COPY_FILE.Properties.Resources.arrows45X200;
            this.button_copy_sourcefile_all_sync.Location = new System.Drawing.Point(534, 23);
            this.button_copy_sourcefile_all_sync.Name = "button_copy_sourcefile_all_sync";
            this.button_copy_sourcefile_all_sync.Size = new System.Drawing.Size(48, 116);
            this.button_copy_sourcefile_all_sync.TabIndex = 34;
            this.button_copy_sourcefile_all_sync.UseVisualStyleBackColor = true;
            this.button_copy_sourcefile_all_sync.Click += new System.EventHandler(this.button_copy_sourcefile_all_Click_sync);
            // 
            // button_copy_destinationfile_sync
            // 
            this.button_copy_destinationfile_sync.Image = global::SYD_COPY_FILE.Properties.Resources.arrows45X50;
            this.button_copy_destinationfile_sync.Location = new System.Drawing.Point(480, 95);
            this.button_copy_destinationfile_sync.Name = "button_copy_destinationfile_sync";
            this.button_copy_destinationfile_sync.Size = new System.Drawing.Size(48, 44);
            this.button_copy_destinationfile_sync.TabIndex = 33;
            this.button_copy_destinationfile_sync.UseVisualStyleBackColor = true;
            this.button_copy_destinationfile_sync.Click += new System.EventHandler(this.button_copy_destinationfile_Click_sync);
            // 
            // button_copy_sourcefile_sync
            // 
            this.button_copy_sourcefile_sync.Image = global::SYD_COPY_FILE.Properties.Resources.arrows45X50;
            this.button_copy_sourcefile_sync.Location = new System.Drawing.Point(467, 28);
            this.button_copy_sourcefile_sync.Name = "button_copy_sourcefile_sync";
            this.button_copy_sourcefile_sync.Size = new System.Drawing.Size(48, 44);
            this.button_copy_sourcefile_sync.TabIndex = 32;
            this.button_copy_sourcefile_sync.UseVisualStyleBackColor = true;
            this.button_copy_sourcefile_sync.Click += new System.EventHandler(this.copy_button_Click_sync);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 41;
            this.label5.Text = "常用路径:";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.checkBox4);
            this.tabPage7.Controls.Add(this.checkBox2);
            this.tabPage7.Controls.Add(this.checkBox_systemtime_rename);
            this.tabPage7.Controls.Add(this.checkBox3);
            this.tabPage7.Controls.Add(this.comboBox_timetype_rename);
            this.tabPage7.Controls.Add(this.button_copy_sourcefile4);
            this.tabPage7.Controls.Add(this.destination_file_button_generate_rename);
            this.tabPage7.Controls.Add(this.source_copyfile_suffix_textBox_rename);
            this.tabPage7.Controls.Add(this.label80);
            this.tabPage7.Controls.Add(this.source_copyfile_prefix_textBox_rename);
            this.tabPage7.Controls.Add(this.source_copyfile_button_rename);
            this.tabPage7.Controls.Add(this.source_copyfile_textBox_rename);
            this.tabPage7.Controls.Add(this.destination_file_textBox_rename);
            this.tabPage7.Controls.Add(this.label82);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(757, 552);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Rename";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(408, 41);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(132, 16);
            this.checkBox4.TabIndex = 47;
            this.checkBox4.Text = "更新原文件时间尾缀";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(408, 60);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(132, 16);
            this.checkBox2.TabIndex = 46;
            this.checkBox2.Text = "删除原文件时间尾缀";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox_systemtime_rename
            // 
            this.checkBox_systemtime_rename.AutoSize = true;
            this.checkBox_systemtime_rename.Location = new System.Drawing.Point(248, 60);
            this.checkBox_systemtime_rename.Name = "checkBox_systemtime_rename";
            this.checkBox_systemtime_rename.Size = new System.Drawing.Size(168, 16);
            this.checkBox_systemtime_rename.TabIndex = 45;
            this.checkBox_systemtime_rename.Text = "文件时间（默认系统时间）";
            this.checkBox_systemtime_rename.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox3.Location = new System.Drawing.Point(1, 60);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(120, 16);
            this.checkBox3.TabIndex = 44;
            this.checkBox3.Text = "文件名后追加时间";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // comboBox_timetype_rename
            // 
            this.comboBox_timetype_rename.FormattingEnabled = true;
            this.comboBox_timetype_rename.Items.AddRange(new object[] {
            "yyyy-MM-dd HHmmss",
            "yyyyMMdd"});
            this.comboBox_timetype_rename.Location = new System.Drawing.Point(123, 58);
            this.comboBox_timetype_rename.Name = "comboBox_timetype_rename";
            this.comboBox_timetype_rename.Size = new System.Drawing.Size(121, 20);
            this.comboBox_timetype_rename.TabIndex = 43;
            // 
            // button_copy_sourcefile4
            // 
            this.button_copy_sourcefile4.Location = new System.Drawing.Point(303, 31);
            this.button_copy_sourcefile4.Name = "button_copy_sourcefile4";
            this.button_copy_sourcefile4.Size = new System.Drawing.Size(41, 22);
            this.button_copy_sourcefile4.TabIndex = 42;
            this.button_copy_sourcefile4.Text = "清空";
            this.button_copy_sourcefile4.UseVisualStyleBackColor = true;
            this.button_copy_sourcefile4.Click += new System.EventHandler(this.button_copy_sourcefile4_Click);
            // 
            // destination_file_button_generate_rename
            // 
            this.destination_file_button_generate_rename.Location = new System.Drawing.Point(462, 80);
            this.destination_file_button_generate_rename.Name = "destination_file_button_generate_rename";
            this.destination_file_button_generate_rename.Size = new System.Drawing.Size(125, 22);
            this.destination_file_button_generate_rename.TabIndex = 41;
            this.destination_file_button_generate_rename.Text = "Generate ";
            this.destination_file_button_generate_rename.UseVisualStyleBackColor = true;
            this.destination_file_button_generate_rename.Click += new System.EventHandler(this.destination_file_button_generate_rename_Click);
            // 
            // source_copyfile_suffix_textBox_rename
            // 
            this.source_copyfile_suffix_textBox_rename.AllowDrop = true;
            this.source_copyfile_suffix_textBox_rename.Location = new System.Drawing.Point(231, 31);
            this.source_copyfile_suffix_textBox_rename.Name = "source_copyfile_suffix_textBox_rename";
            this.source_copyfile_suffix_textBox_rename.Size = new System.Drawing.Size(66, 21);
            this.source_copyfile_suffix_textBox_rename.TabIndex = 39;
            // 
            // label80
            // 
            this.label80.Font = new System.Drawing.Font("宋体", 10F);
            this.label80.Location = new System.Drawing.Point(149, 33);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(101, 24);
            this.label80.TabIndex = 40;
            this.label80.Text = "文件名尾缀:";
            // 
            // source_copyfile_prefix_textBox_rename
            // 
            this.source_copyfile_prefix_textBox_rename.AllowDrop = true;
            this.source_copyfile_prefix_textBox_rename.Location = new System.Drawing.Point(80, 31);
            this.source_copyfile_prefix_textBox_rename.Name = "source_copyfile_prefix_textBox_rename";
            this.source_copyfile_prefix_textBox_rename.Size = new System.Drawing.Size(66, 21);
            this.source_copyfile_prefix_textBox_rename.TabIndex = 37;
            this.source_copyfile_prefix_textBox_rename.Text = "UART";
            // 
            // source_copyfile_button_rename
            // 
            this.source_copyfile_button_rename.Location = new System.Drawing.Point(462, 1);
            this.source_copyfile_button_rename.Name = "source_copyfile_button_rename";
            this.source_copyfile_button_rename.Size = new System.Drawing.Size(125, 22);
            this.source_copyfile_button_rename.TabIndex = 34;
            this.source_copyfile_button_rename.Text = "Source file";
            this.source_copyfile_button_rename.UseVisualStyleBackColor = true;
            this.source_copyfile_button_rename.Click += new System.EventHandler(this.source_copyfile_button_rename_Click);
            // 
            // source_copyfile_textBox_rename
            // 
            this.source_copyfile_textBox_rename.AllowDrop = true;
            this.source_copyfile_textBox_rename.Location = new System.Drawing.Point(3, 3);
            this.source_copyfile_textBox_rename.Name = "source_copyfile_textBox_rename";
            this.source_copyfile_textBox_rename.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.source_copyfile_textBox_rename.Size = new System.Drawing.Size(454, 21);
            this.source_copyfile_textBox_rename.TabIndex = 35;
            this.source_copyfile_textBox_rename.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.source_copyfile_textBox_rename.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // destination_file_textBox_rename
            // 
            this.destination_file_textBox_rename.AllowDrop = true;
            this.destination_file_textBox_rename.Location = new System.Drawing.Point(3, 81);
            this.destination_file_textBox_rename.Name = "destination_file_textBox_rename";
            this.destination_file_textBox_rename.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.destination_file_textBox_rename.Size = new System.Drawing.Size(454, 21);
            this.destination_file_textBox_rename.TabIndex = 36;
            // 
            // label82
            // 
            this.label82.Font = new System.Drawing.Font("宋体", 10F);
            this.label82.Location = new System.Drawing.Point(-2, 33);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(101, 24);
            this.label82.TabIndex = 38;
            this.label82.Text = "文件名前缀:";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.button_copy_sourcefile5);
            this.tabPage8.Controls.Add(this.button_splitbinfile);
            this.tabPage8.Controls.Add(this.textBox_splitbinfile);
            this.tabPage8.Controls.Add(this.textBox_section1);
            this.tabPage8.Controls.Add(this.comboBox_splittype);
            this.tabPage8.Controls.Add(this.textBox_sectionout6);
            this.tabPage8.Controls.Add(this.textBox_sectionout5);
            this.tabPage8.Controls.Add(this.textBox_sectionout4);
            this.tabPage8.Controls.Add(this.textBox_sectionout3);
            this.tabPage8.Controls.Add(this.textBox_sectionout2);
            this.tabPage8.Controls.Add(this.textBox_sectionout1);
            this.tabPage8.Controls.Add(this.button_split);
            this.tabPage8.Controls.Add(this.textBox_section5);
            this.tabPage8.Controls.Add(this.label85);
            this.tabPage8.Controls.Add(this.textBox_section4);
            this.tabPage8.Controls.Add(this.label86);
            this.tabPage8.Controls.Add(this.textBox_section3);
            this.tabPage8.Controls.Add(this.label87);
            this.tabPage8.Controls.Add(this.textBox_section2);
            this.tabPage8.Controls.Add(this.label88);
            this.tabPage8.Controls.Add(this.label89);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(757, 552);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "BIN_Split";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // button_copy_sourcefile5
            // 
            this.button_copy_sourcefile5.Location = new System.Drawing.Point(535, 2);
            this.button_copy_sourcefile5.Name = "button_copy_sourcefile5";
            this.button_copy_sourcefile5.Size = new System.Drawing.Size(55, 22);
            this.button_copy_sourcefile5.TabIndex = 60;
            this.button_copy_sourcefile5.Text = "Clear";
            this.button_copy_sourcefile5.UseVisualStyleBackColor = true;
            this.button_copy_sourcefile5.Click += new System.EventHandler(this.button_copy_sourcefile5_Click);
            // 
            // button_splitbinfile
            // 
            this.button_splitbinfile.Location = new System.Drawing.Point(463, 2);
            this.button_splitbinfile.Name = "button_splitbinfile";
            this.button_splitbinfile.Size = new System.Drawing.Size(55, 22);
            this.button_splitbinfile.TabIndex = 40;
            this.button_splitbinfile.Text = "Open";
            this.button_splitbinfile.UseVisualStyleBackColor = true;
            this.button_splitbinfile.Click += new System.EventHandler(this.button_splitbinfile_Click);
            // 
            // textBox_splitbinfile
            // 
            this.textBox_splitbinfile.AllowDrop = true;
            this.textBox_splitbinfile.Location = new System.Drawing.Point(6, 2);
            this.textBox_splitbinfile.Name = "textBox_splitbinfile";
            this.textBox_splitbinfile.Size = new System.Drawing.Size(454, 21);
            this.textBox_splitbinfile.TabIndex = 41;
            this.textBox_splitbinfile.DragDrop += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragDrop);
            this.textBox_splitbinfile.DragEnter += new System.Windows.Forms.DragEventHandler(this.source_copyfile_textBox_DragEnter);
            // 
            // textBox_section1
            // 
            this.textBox_section1.Location = new System.Drawing.Point(61, 49);
            this.textBox_section1.Name = "textBox_section1";
            this.textBox_section1.Size = new System.Drawing.Size(99, 21);
            this.textBox_section1.TabIndex = 43;
            this.textBox_section1.Text = "0x00001000";
            this.textBox_section1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBox_splittype
            // 
            this.comboBox_splittype.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.comboBox_splittype.Font = new System.Drawing.Font("宋体", 10F, System.Drawing.FontStyle.Bold);
            this.comboBox_splittype.FormattingEnabled = true;
            this.comboBox_splittype.Items.AddRange(new object[] {
            "Size",
            "Addr"});
            this.comboBox_splittype.Location = new System.Drawing.Point(7, 24);
            this.comboBox_splittype.Name = "comboBox_splittype";
            this.comboBox_splittype.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.comboBox_splittype.Size = new System.Drawing.Size(54, 21);
            this.comboBox_splittype.TabIndex = 59;
            this.comboBox_splittype.Text = "Size";
            // 
            // textBox_sectionout6
            // 
            this.textBox_sectionout6.AllowDrop = true;
            this.textBox_sectionout6.Location = new System.Drawing.Point(162, 25);
            this.textBox_sectionout6.Name = "textBox_sectionout6";
            this.textBox_sectionout6.Size = new System.Drawing.Size(428, 21);
            this.textBox_sectionout6.TabIndex = 58;
            // 
            // textBox_sectionout5
            // 
            this.textBox_sectionout5.AllowDrop = true;
            this.textBox_sectionout5.Location = new System.Drawing.Point(162, 140);
            this.textBox_sectionout5.Name = "textBox_sectionout5";
            this.textBox_sectionout5.Size = new System.Drawing.Size(428, 21);
            this.textBox_sectionout5.TabIndex = 57;
            // 
            // textBox_sectionout4
            // 
            this.textBox_sectionout4.AllowDrop = true;
            this.textBox_sectionout4.Location = new System.Drawing.Point(162, 118);
            this.textBox_sectionout4.Name = "textBox_sectionout4";
            this.textBox_sectionout4.Size = new System.Drawing.Size(428, 21);
            this.textBox_sectionout4.TabIndex = 56;
            // 
            // textBox_sectionout3
            // 
            this.textBox_sectionout3.AllowDrop = true;
            this.textBox_sectionout3.Location = new System.Drawing.Point(162, 95);
            this.textBox_sectionout3.Name = "textBox_sectionout3";
            this.textBox_sectionout3.Size = new System.Drawing.Size(428, 21);
            this.textBox_sectionout3.TabIndex = 55;
            // 
            // textBox_sectionout2
            // 
            this.textBox_sectionout2.AllowDrop = true;
            this.textBox_sectionout2.Location = new System.Drawing.Point(162, 72);
            this.textBox_sectionout2.Name = "textBox_sectionout2";
            this.textBox_sectionout2.Size = new System.Drawing.Size(428, 21);
            this.textBox_sectionout2.TabIndex = 54;
            // 
            // textBox_sectionout1
            // 
            this.textBox_sectionout1.AllowDrop = true;
            this.textBox_sectionout1.Location = new System.Drawing.Point(162, 49);
            this.textBox_sectionout1.Name = "textBox_sectionout1";
            this.textBox_sectionout1.Size = new System.Drawing.Size(428, 21);
            this.textBox_sectionout1.TabIndex = 53;
            // 
            // button_split
            // 
            this.button_split.Location = new System.Drawing.Point(72, 22);
            this.button_split.Name = "button_split";
            this.button_split.Size = new System.Drawing.Size(75, 23);
            this.button_split.TabIndex = 52;
            this.button_split.Text = "Split";
            this.button_split.UseVisualStyleBackColor = true;
            this.button_split.Click += new System.EventHandler(this.button_split_Click);
            // 
            // textBox_section5
            // 
            this.textBox_section5.Location = new System.Drawing.Point(61, 140);
            this.textBox_section5.Name = "textBox_section5";
            this.textBox_section5.Size = new System.Drawing.Size(99, 21);
            this.textBox_section5.TabIndex = 51;
            this.textBox_section5.Text = "0x00010000";
            this.textBox_section5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(4, 143);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(59, 12);
            this.label85.TabIndex = 50;
            this.label85.Text = "Section5:";
            // 
            // textBox_section4
            // 
            this.textBox_section4.Location = new System.Drawing.Point(61, 117);
            this.textBox_section4.Name = "textBox_section4";
            this.textBox_section4.Size = new System.Drawing.Size(99, 21);
            this.textBox_section4.TabIndex = 49;
            this.textBox_section4.Text = "0x00008000";
            this.textBox_section4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(4, 120);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(59, 12);
            this.label86.TabIndex = 48;
            this.label86.Text = "Section4:";
            // 
            // textBox_section3
            // 
            this.textBox_section3.Location = new System.Drawing.Point(61, 95);
            this.textBox_section3.Name = "textBox_section3";
            this.textBox_section3.Size = new System.Drawing.Size(99, 21);
            this.textBox_section3.TabIndex = 47;
            this.textBox_section3.Text = "0x00004000";
            this.textBox_section3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(4, 98);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(59, 12);
            this.label87.TabIndex = 46;
            this.label87.Text = "Section3:";
            // 
            // textBox_section2
            // 
            this.textBox_section2.Location = new System.Drawing.Point(61, 72);
            this.textBox_section2.Name = "textBox_section2";
            this.textBox_section2.Size = new System.Drawing.Size(99, 21);
            this.textBox_section2.TabIndex = 45;
            this.textBox_section2.Text = "0x00001000";
            this.textBox_section2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(4, 75);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(59, 12);
            this.label88.TabIndex = 44;
            this.label88.Text = "Section2:";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("宋体", 9F);
            this.label89.Location = new System.Drawing.Point(4, 54);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(59, 12);
            this.label89.TabIndex = 42;
            this.label89.Text = "Section1:";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.button_sectionintput6);
            this.tabPage9.Controls.Add(this.textBox_sectionintput6);
            this.tabPage9.Controls.Add(this.button_sectionintput1);
            this.tabPage9.Controls.Add(this.button_sectionintput5);
            this.tabPage9.Controls.Add(this.textBox_sectionintput1);
            this.tabPage9.Controls.Add(this.textBox_sectionintput5);
            this.tabPage9.Controls.Add(this.button_sectionintput2);
            this.tabPage9.Controls.Add(this.button_sectionintput4);
            this.tabPage9.Controls.Add(this.textBox_sectionintput2);
            this.tabPage9.Controls.Add(this.textBox_sectionintput4);
            this.tabPage9.Controls.Add(this.button_sectionintput3);
            this.tabPage9.Controls.Add(this.textBox_sectionintput3);
            this.tabPage9.Controls.Add(this.label_nowtime1);
            this.tabPage9.Controls.Add(this.button_combine);
            this.tabPage9.Controls.Add(this.label_nowtime2);
            this.tabPage9.Controls.Add(this.label_nowtime4);
            this.tabPage9.Controls.Add(this.label90);
            this.tabPage9.Controls.Add(this.label_nowtime3);
            this.tabPage9.Controls.Add(this.label_nowtime0);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(757, 552);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "BIN_Combin";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // button_sectionintput6
            // 
            this.button_sectionintput6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_sectionintput6.Location = new System.Drawing.Point(522, 117);
            this.button_sectionintput6.Name = "button_sectionintput6";
            this.button_sectionintput6.Size = new System.Drawing.Size(61, 21);
            this.button_sectionintput6.TabIndex = 42;
            this.button_sectionintput6.Text = "Open";
            this.button_sectionintput6.UseVisualStyleBackColor = true;
            this.button_sectionintput6.Click += new System.EventHandler(this.button_combinopen_Click);
            // 
            // textBox_sectionintput6
            // 
            this.textBox_sectionintput6.AllowDrop = true;
            this.textBox_sectionintput6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox_sectionintput6.Location = new System.Drawing.Point(62, 117);
            this.textBox_sectionintput6.Name = "textBox_sectionintput6";
            this.textBox_sectionintput6.Size = new System.Drawing.Size(454, 20);
            this.textBox_sectionintput6.TabIndex = 43;
            // 
            // button_sectionintput1
            // 
            this.button_sectionintput1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_sectionintput1.Location = new System.Drawing.Point(522, 3);
            this.button_sectionintput1.Name = "button_sectionintput1";
            this.button_sectionintput1.Size = new System.Drawing.Size(61, 21);
            this.button_sectionintput1.TabIndex = 26;
            this.button_sectionintput1.Text = "Open";
            this.button_sectionintput1.UseVisualStyleBackColor = true;
            this.button_sectionintput1.Click += new System.EventHandler(this.button_combinopen_Click);
            // 
            // button_sectionintput5
            // 
            this.button_sectionintput5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_sectionintput5.Location = new System.Drawing.Point(522, 95);
            this.button_sectionintput5.Name = "button_sectionintput5";
            this.button_sectionintput5.Size = new System.Drawing.Size(61, 21);
            this.button_sectionintput5.TabIndex = 39;
            this.button_sectionintput5.Text = "Open";
            this.button_sectionintput5.UseVisualStyleBackColor = true;
            this.button_sectionintput5.Click += new System.EventHandler(this.button_combinopen_Click);
            // 
            // textBox_sectionintput1
            // 
            this.textBox_sectionintput1.AllowDrop = true;
            this.textBox_sectionintput1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox_sectionintput1.Location = new System.Drawing.Point(62, 4);
            this.textBox_sectionintput1.Name = "textBox_sectionintput1";
            this.textBox_sectionintput1.Size = new System.Drawing.Size(454, 20);
            this.textBox_sectionintput1.TabIndex = 27;
            // 
            // textBox_sectionintput5
            // 
            this.textBox_sectionintput5.AllowDrop = true;
            this.textBox_sectionintput5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox_sectionintput5.Location = new System.Drawing.Point(62, 95);
            this.textBox_sectionintput5.Name = "textBox_sectionintput5";
            this.textBox_sectionintput5.Size = new System.Drawing.Size(454, 20);
            this.textBox_sectionintput5.TabIndex = 40;
            // 
            // button_sectionintput2
            // 
            this.button_sectionintput2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_sectionintput2.Location = new System.Drawing.Point(522, 24);
            this.button_sectionintput2.Name = "button_sectionintput2";
            this.button_sectionintput2.Size = new System.Drawing.Size(61, 24);
            this.button_sectionintput2.TabIndex = 30;
            this.button_sectionintput2.Text = "Open";
            this.button_sectionintput2.UseVisualStyleBackColor = true;
            this.button_sectionintput2.Click += new System.EventHandler(this.button_combinopen_Click);
            // 
            // button_sectionintput4
            // 
            this.button_sectionintput4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_sectionintput4.Location = new System.Drawing.Point(522, 72);
            this.button_sectionintput4.Name = "button_sectionintput4";
            this.button_sectionintput4.Size = new System.Drawing.Size(61, 21);
            this.button_sectionintput4.TabIndex = 36;
            this.button_sectionintput4.Text = "Open";
            this.button_sectionintput4.UseVisualStyleBackColor = true;
            this.button_sectionintput4.Click += new System.EventHandler(this.button_combinopen_Click);
            // 
            // textBox_sectionintput2
            // 
            this.textBox_sectionintput2.AllowDrop = true;
            this.textBox_sectionintput2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox_sectionintput2.Location = new System.Drawing.Point(62, 27);
            this.textBox_sectionintput2.Name = "textBox_sectionintput2";
            this.textBox_sectionintput2.Size = new System.Drawing.Size(454, 20);
            this.textBox_sectionintput2.TabIndex = 31;
            // 
            // textBox_sectionintput4
            // 
            this.textBox_sectionintput4.AllowDrop = true;
            this.textBox_sectionintput4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox_sectionintput4.Location = new System.Drawing.Point(62, 72);
            this.textBox_sectionintput4.Name = "textBox_sectionintput4";
            this.textBox_sectionintput4.Size = new System.Drawing.Size(454, 20);
            this.textBox_sectionintput4.TabIndex = 37;
            // 
            // button_sectionintput3
            // 
            this.button_sectionintput3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.button_sectionintput3.Location = new System.Drawing.Point(522, 48);
            this.button_sectionintput3.Name = "button_sectionintput3";
            this.button_sectionintput3.Size = new System.Drawing.Size(61, 21);
            this.button_sectionintput3.TabIndex = 33;
            this.button_sectionintput3.Text = "Open";
            this.button_sectionintput3.UseVisualStyleBackColor = true;
            this.button_sectionintput3.Click += new System.EventHandler(this.button_combinopen_Click);
            // 
            // textBox_sectionintput3
            // 
            this.textBox_sectionintput3.AllowDrop = true;
            this.textBox_sectionintput3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox_sectionintput3.Location = new System.Drawing.Point(62, 49);
            this.textBox_sectionintput3.Name = "textBox_sectionintput3";
            this.textBox_sectionintput3.Size = new System.Drawing.Size(454, 20);
            this.textBox_sectionintput3.TabIndex = 34;
            // 
            // label_nowtime1
            // 
            this.label_nowtime1.AutoSize = true;
            this.label_nowtime1.Font = new System.Drawing.Font("宋体", 9F);
            this.label_nowtime1.Location = new System.Drawing.Point(5, 119);
            this.label_nowtime1.Name = "label_nowtime1";
            this.label_nowtime1.Size = new System.Drawing.Size(59, 12);
            this.label_nowtime1.TabIndex = 44;
            this.label_nowtime1.Text = "Section6:";
            // 
            // button_combine
            // 
            this.button_combine.Location = new System.Drawing.Point(466, 142);
            this.button_combine.Name = "button_combine";
            this.button_combine.Size = new System.Drawing.Size(117, 21);
            this.button_combine.TabIndex = 29;
            this.button_combine.Text = "Combine";
            this.button_combine.UseVisualStyleBackColor = true;
            this.button_combine.Click += new System.EventHandler(this.button_combine_Click);
            // 
            // label_nowtime2
            // 
            this.label_nowtime2.AutoSize = true;
            this.label_nowtime2.Font = new System.Drawing.Font("宋体", 9F);
            this.label_nowtime2.Location = new System.Drawing.Point(5, 97);
            this.label_nowtime2.Name = "label_nowtime2";
            this.label_nowtime2.Size = new System.Drawing.Size(59, 12);
            this.label_nowtime2.TabIndex = 41;
            this.label_nowtime2.Text = "Section5:";
            // 
            // label_nowtime4
            // 
            this.label_nowtime4.AutoSize = true;
            this.label_nowtime4.Font = new System.Drawing.Font("宋体", 9F);
            this.label_nowtime4.Location = new System.Drawing.Point(5, 9);
            this.label_nowtime4.Name = "label_nowtime4";
            this.label_nowtime4.Size = new System.Drawing.Size(59, 12);
            this.label_nowtime4.TabIndex = 28;
            this.label_nowtime4.Text = "Section1:";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("宋体", 9F);
            this.label90.Location = new System.Drawing.Point(5, 75);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(59, 12);
            this.label90.TabIndex = 38;
            this.label90.Text = "Section4:";
            // 
            // label_nowtime3
            // 
            this.label_nowtime3.AutoSize = true;
            this.label_nowtime3.Font = new System.Drawing.Font("宋体", 9F);
            this.label_nowtime3.Location = new System.Drawing.Point(5, 30);
            this.label_nowtime3.Name = "label_nowtime3";
            this.label_nowtime3.Size = new System.Drawing.Size(59, 12);
            this.label_nowtime3.TabIndex = 32;
            this.label_nowtime3.Text = "Section2:";
            // 
            // label_nowtime0
            // 
            this.label_nowtime0.AutoSize = true;
            this.label_nowtime0.Font = new System.Drawing.Font("宋体", 9F);
            this.label_nowtime0.Location = new System.Drawing.Point(5, 52);
            this.label_nowtime0.Name = "label_nowtime0";
            this.label_nowtime0.Size = new System.Drawing.Size(59, 12);
            this.label_nowtime0.TabIndex = 35;
            this.label_nowtime0.Text = "Section3:";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox14);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(757, 552);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "timer/cal";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.textBox61);
            this.groupBox14.Controls.Add(this.label59);
            this.groupBox14.Controls.Add(this.label61);
            this.groupBox14.Controls.Add(this.textBox63);
            this.groupBox14.Font = new System.Drawing.Font("宋体", 9F);
            this.groupBox14.Location = new System.Drawing.Point(582, 3);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(167, 71);
            this.groupBox14.TabIndex = 34;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "hex_overturn";
            // 
            // textBox61
            // 
            this.textBox61.AllowDrop = true;
            this.textBox61.Location = new System.Drawing.Point(44, 40);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(117, 21);
            this.textBox61.TabIndex = 36;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(-1, 43);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(47, 12);
            this.label59.TabIndex = 37;
            this.label59.Text = "output:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(0, 17);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(41, 12);
            this.label61.TabIndex = 35;
            this.label61.Text = "input:";
            // 
            // textBox63
            // 
            this.textBox63.AllowDrop = true;
            this.textBox63.Location = new System.Drawing.Point(44, 14);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(117, 21);
            this.textBox63.TabIndex = 2;
            this.textBox63.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox63_KeyDown);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.checkBox1);
            this.groupBox4.Controls.Add(this.button20);
            this.groupBox4.Controls.Add(this.button23);
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.textBox10);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.panel13);
            this.groupBox4.Controls.Add(this.panel16);
            this.groupBox4.Location = new System.Drawing.Point(452, 176);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(300, 372);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "批量差值";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.checkBox1.Location = new System.Drawing.Point(119, 292);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(42, 16);
            this.checkBox1.TabIndex = 41;
            this.checkBox1.Text = "HEX";
            this.checkBox1.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(112, 9);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(86, 22);
            this.button20.TabIndex = 30;
            this.button20.Text = "计算时间差值";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(124, 36);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(61, 22);
            this.button23.TabIndex = 31;
            this.button23.Text = "清空";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // textBox11
            // 
            this.textBox11.AllowDrop = true;
            this.textBox11.Location = new System.Drawing.Point(193, 32);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(104, 334);
            this.textBox11.TabIndex = 26;
            // 
            // textBox10
            // 
            this.textBox10.AllowDrop = true;
            this.textBox10.Location = new System.Drawing.Point(3, 32);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(113, 334);
            this.textBox10.TabIndex = 25;
            this.textBox10.Text = "3.133\r\n2.618\r\n2.401\r\n1.801\r\n1.574\r\n1.008\r\n0.395\r\n0.046\r\n0.000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 12);
            this.label2.TabIndex = 27;
            this.label2.Text = "INPUT(3.133)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(226, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 28;
            this.label3.Text = "RESULT";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.label66);
            this.panel13.Controls.Add(this.textBox65);
            this.panel13.Controls.Add(this.textBox64);
            this.panel13.Controls.Add(this.button4);
            this.panel13.Controls.Add(this.label65);
            this.panel13.Controls.Add(this.label63);
            this.panel13.Controls.Add(this.button22);
            this.panel13.Controls.Add(this.label64);
            this.panel13.Controls.Add(this.textBox62);
            this.panel13.Location = new System.Drawing.Point(118, 93);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(73, 194);
            this.panel13.TabIndex = 39;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(3, 125);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(65, 12);
            this.label66.TabIndex = 40;
            this.label66.Text = "数量(dec):";
            // 
            // textBox65
            // 
            this.textBox65.AllowDrop = true;
            this.textBox65.Location = new System.Drawing.Point(5, 144);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(61, 21);
            this.textBox65.TabIndex = 39;
            this.textBox65.Text = "20";
            // 
            // textBox64
            // 
            this.textBox64.AllowDrop = true;
            this.textBox64.Location = new System.Drawing.Point(5, 102);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(61, 21);
            this.textBox64.TabIndex = 37;
            this.textBox64.Text = "0x1000";
            // 
            // button4
            // 
            this.button4.Image = global::SYD_COPY_FILE.Properties.Resources.dowm;
            this.button4.Location = new System.Drawing.Point(33, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(35, 39);
            this.button4.TabIndex = 31;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(3, 83);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(65, 12);
            this.label65.TabIndex = 38;
            this.label65.Text = "差值(hex):";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(-2, 15);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(35, 12);
            this.label63.TabIndex = 26;
            this.label63.Text = "方向:";
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(5, 168);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(61, 22);
            this.button22.TabIndex = 35;
            this.button22.Text = "生成数组";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(3, 41);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(65, 12);
            this.label64.TabIndex = 36;
            this.label64.Text = "差值(dec):";
            // 
            // textBox62
            // 
            this.textBox62.AllowDrop = true;
            this.textBox62.Location = new System.Drawing.Point(5, 60);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(61, 21);
            this.textBox62.TabIndex = 35;
            this.textBox62.Text = "4";
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.button3);
            this.panel16.Location = new System.Drawing.Point(119, 59);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(71, 28);
            this.panel16.TabIndex = 40;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(61, 22);
            this.button3.TabIndex = 30;
            this.button3.Text = "计算差值";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBox43);
            this.groupBox7.Controls.Add(this.textBox44);
            this.groupBox7.Controls.Add(this.textBox45);
            this.groupBox7.Controls.Add(this.textBox46);
            this.groupBox7.Controls.Add(this.textBox47);
            this.groupBox7.Controls.Add(this.textBox48);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.button13);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.button14);
            this.groupBox7.Controls.Add(this.textBox49);
            this.groupBox7.Controls.Add(this.textBox50);
            this.groupBox7.Controls.Add(this.textBox51);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.button15);
            this.groupBox7.Location = new System.Drawing.Point(0, 285);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(449, 108);
            this.groupBox7.TabIndex = 24;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "SYDTEK_RTC_Counter Difference(0x23120D08)";
            // 
            // textBox43
            // 
            this.textBox43.AllowDrop = true;
            this.textBox43.Location = new System.Drawing.Point(340, 77);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 21);
            this.textBox43.TabIndex = 39;
            // 
            // textBox44
            // 
            this.textBox44.AllowDrop = true;
            this.textBox44.Location = new System.Drawing.Point(340, 46);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 21);
            this.textBox44.TabIndex = 33;
            // 
            // textBox45
            // 
            this.textBox45.AllowDrop = true;
            this.textBox45.Location = new System.Drawing.Point(212, 78);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(68, 21);
            this.textBox45.TabIndex = 38;
            this.textBox45.Text = "0x23120D08";
            // 
            // textBox46
            // 
            this.textBox46.AllowDrop = true;
            this.textBox46.Location = new System.Drawing.Point(212, 47);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(68, 21);
            this.textBox46.TabIndex = 32;
            this.textBox46.Text = "0x23120D08";
            // 
            // textBox47
            // 
            this.textBox47.AllowDrop = true;
            this.textBox47.Location = new System.Drawing.Point(61, 76);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(69, 21);
            this.textBox47.TabIndex = 36;
            this.textBox47.Text = "0x23128560";
            // 
            // textBox48
            // 
            this.textBox48.AllowDrop = true;
            this.textBox48.Location = new System.Drawing.Point(61, 45);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(69, 21);
            this.textBox48.TabIndex = 30;
            this.textBox48.Text = "0x23128560";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(4, 79);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 12);
            this.label29.TabIndex = 37;
            this.label29.Text = "Now Time:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(133, 81);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(77, 12);
            this.label30.TabIndex = 35;
            this.label30.Text = "Before Time:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(4, 48);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(59, 12);
            this.label31.TabIndex = 31;
            this.label31.Text = "Now Time:";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(281, 77);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(53, 22);
            this.button13.TabIndex = 34;
            this.button13.Text = "cal";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(133, 50);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(77, 12);
            this.label32.TabIndex = 29;
            this.label32.Text = "Before Time:";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(281, 46);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(53, 22);
            this.button14.TabIndex = 28;
            this.button14.Text = "cal";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // textBox49
            // 
            this.textBox49.AllowDrop = true;
            this.textBox49.Location = new System.Drawing.Point(340, 19);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 21);
            this.textBox49.TabIndex = 26;
            // 
            // textBox50
            // 
            this.textBox50.AllowDrop = true;
            this.textBox50.Location = new System.Drawing.Point(212, 20);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(68, 21);
            this.textBox50.TabIndex = 25;
            this.textBox50.Text = "0x000B30B3";
            // 
            // textBox51
            // 
            this.textBox51.AllowDrop = true;
            this.textBox51.Location = new System.Drawing.Point(61, 18);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(69, 21);
            this.textBox51.TabIndex = 23;
            this.textBox51.Text = "0x008AF555";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(4, 21);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(59, 12);
            this.label33.TabIndex = 24;
            this.label33.Text = "Now Time:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(133, 23);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(77, 12);
            this.label34.TabIndex = 22;
            this.label34.Text = "Before Time:";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(281, 19);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(53, 22);
            this.button15.TabIndex = 0;
            this.button15.Text = "cal";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // LED_Display
            // 
            this.LED_Display.Controls.Add(this.groupBox15);
            this.LED_Display.Controls.Add(this.groupBox11);
            this.LED_Display.Controls.Add(this.groupBox9);
            this.LED_Display.Controls.Add(this.groupBox8);
            this.LED_Display.Location = new System.Drawing.Point(4, 22);
            this.LED_Display.Name = "LED_Display";
            this.LED_Display.Padding = new System.Windows.Forms.Padding(3);
            this.LED_Display.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.LED_Display.Size = new System.Drawing.Size(757, 552);
            this.LED_Display.TabIndex = 1;
            this.LED_Display.Text = "LED/RGB";
            this.LED_Display.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.textBoxy1);
            this.groupBox15.Controls.Add(this.pictureBox16);
            this.groupBox15.Controls.Add(this.pictureBox17);
            this.groupBox15.Controls.Add(this.textBoxx1);
            this.groupBox15.Controls.Add(this.pictureBox14);
            this.groupBox15.Controls.Add(this.pictureBox15);
            this.groupBox15.Controls.Add(this.label62);
            this.groupBox15.Controls.Add(this.label60);
            this.groupBox15.Controls.Add(this.label53);
            this.groupBox15.Controls.Add(this.textBox_Num8);
            this.groupBox15.Controls.Add(this.button_font8);
            this.groupBox15.Controls.Add(this.textBox_Num7);
            this.groupBox15.Controls.Add(this.textBox_Hight8);
            this.groupBox15.Controls.Add(this.textBox_Num6);
            this.groupBox15.Controls.Add(this.textBox_Num5);
            this.groupBox15.Controls.Add(this.textBox_Width8);
            this.groupBox15.Controls.Add(this.textBox_Num4);
            this.groupBox15.Controls.Add(this.button_font7);
            this.groupBox15.Controls.Add(this.textBox_Num3);
            this.groupBox15.Controls.Add(this.textBox_Hight7);
            this.groupBox15.Controls.Add(this.textBox_Num2);
            this.groupBox15.Controls.Add(this.textBox_Width7);
            this.groupBox15.Controls.Add(this.textBox_Num1);
            this.groupBox15.Controls.Add(this.button_font6);
            this.groupBox15.Controls.Add(this.textBox_Hight6);
            this.groupBox15.Controls.Add(this.textBox_Width6);
            this.groupBox15.Controls.Add(this.button_font5);
            this.groupBox15.Controls.Add(this.textBox_Hight5);
            this.groupBox15.Controls.Add(this.textBox_Width5);
            this.groupBox15.Controls.Add(this.button_font4);
            this.groupBox15.Controls.Add(this.textBox_Hight4);
            this.groupBox15.Controls.Add(this.textBox_Width4);
            this.groupBox15.Controls.Add(this.button_font3);
            this.groupBox15.Controls.Add(this.textBox_Hight3);
            this.groupBox15.Controls.Add(this.textBox_Width3);
            this.groupBox15.Controls.Add(this.button_font2);
            this.groupBox15.Controls.Add(this.textBox_Hight2);
            this.groupBox15.Controls.Add(this.textBox_Width2);
            this.groupBox15.Controls.Add(this.button_font1);
            this.groupBox15.Controls.Add(this.textBox_Hight1);
            this.groupBox15.Controls.Add(this.textBox_Width1);
            this.groupBox15.Controls.Add(this.textBox_outsideh);
            this.groupBox15.Controls.Add(this.textBox_outsidew);
            this.groupBox15.Controls.Add(this.pictureBox5);
            this.groupBox15.Controls.Add(this.pictureBox4);
            this.groupBox15.Controls.Add(this.pictureBox3);
            this.groupBox15.Controls.Add(this.pictureBox2);
            this.groupBox15.Controls.Add(this.panel2);
            this.groupBox15.Controls.Add(this.pictureBox1);
            this.groupBox15.Controls.Add(this.panel17);
            this.groupBox15.Location = new System.Drawing.Point(190, 231);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(514, 304);
            this.groupBox15.TabIndex = 24;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Offect";
            // 
            // textBoxy1
            // 
            this.textBoxy1.Location = new System.Drawing.Point(457, 114);
            this.textBoxy1.Name = "textBoxy1";
            this.textBoxy1.Size = new System.Drawing.Size(51, 21);
            this.textBoxy1.TabIndex = 75;
            this.textBoxy1.Text = "24";
            this.textBoxy1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::SYD_COPY_FILE.Properties.Resources.arrows3;
            this.pictureBox16.Location = new System.Drawing.Point(459, 138);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(23, 60);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 74;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::SYD_COPY_FILE.Properties.Resources.arrows1;
            this.pictureBox17.Location = new System.Drawing.Point(460, 51);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(23, 60);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox17.TabIndex = 73;
            this.pictureBox17.TabStop = false;
            // 
            // textBoxx1
            // 
            this.textBoxx1.Location = new System.Drawing.Point(281, 273);
            this.textBoxx1.Name = "textBoxx1";
            this.textBoxx1.Size = new System.Drawing.Size(72, 21);
            this.textBoxx1.TabIndex = 72;
            this.textBoxx1.Text = "50";
            this.textBoxx1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::SYD_COPY_FILE.Properties.Resources.arrows4;
            this.pictureBox14.Location = new System.Drawing.Point(251, 272);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(24, 25);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 71;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox15.Image = global::SYD_COPY_FILE.Properties.Resources.arrows2;
            this.pictureBox15.Location = new System.Drawing.Point(359, 272);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(30, 25);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 70;
            this.pictureBox15.TabStop = false;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(150, 24);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(23, 12);
            this.label62.TabIndex = 69;
            this.label62.Text = "Num";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(86, 24);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(41, 12);
            this.label60.TabIndex = 68;
            this.label60.Text = "Highth";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(13, 24);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(35, 12);
            this.label53.TabIndex = 35;
            this.label53.Text = "Width";
            // 
            // textBox_Num8
            // 
            this.textBox_Num8.Location = new System.Drawing.Point(135, 229);
            this.textBox_Num8.Name = "textBox_Num8";
            this.textBox_Num8.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num8.TabIndex = 67;
            this.textBox_Num8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font8
            // 
            this.button_font8.Location = new System.Drawing.Point(58, 225);
            this.button_font8.Name = "button_font8";
            this.button_font8.Size = new System.Drawing.Size(19, 27);
            this.button_font8.TabIndex = 57;
            this.button_font8.Text = "X";
            this.button_font8.UseVisualStyleBackColor = true;
            this.button_font8.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Num7
            // 
            this.textBox_Num7.Location = new System.Drawing.Point(135, 202);
            this.textBox_Num7.Name = "textBox_Num7";
            this.textBox_Num7.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num7.TabIndex = 66;
            this.textBox_Num7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Hight8
            // 
            this.textBox_Hight8.Location = new System.Drawing.Point(81, 229);
            this.textBox_Hight8.Name = "textBox_Hight8";
            this.textBox_Hight8.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight8.TabIndex = 59;
            this.textBox_Hight8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Num6
            // 
            this.textBox_Num6.Location = new System.Drawing.Point(135, 175);
            this.textBox_Num6.Name = "textBox_Num6";
            this.textBox_Num6.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num6.TabIndex = 65;
            this.textBox_Num6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Num5
            // 
            this.textBox_Num5.Location = new System.Drawing.Point(135, 148);
            this.textBox_Num5.Name = "textBox_Num5";
            this.textBox_Num5.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num5.TabIndex = 64;
            this.textBox_Num5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width8
            // 
            this.textBox_Width8.Location = new System.Drawing.Point(5, 229);
            this.textBox_Width8.Name = "textBox_Width8";
            this.textBox_Width8.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width8.TabIndex = 58;
            this.textBox_Width8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Num4
            // 
            this.textBox_Num4.Location = new System.Drawing.Point(135, 121);
            this.textBox_Num4.Name = "textBox_Num4";
            this.textBox_Num4.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num4.TabIndex = 63;
            this.textBox_Num4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font7
            // 
            this.button_font7.Location = new System.Drawing.Point(58, 198);
            this.button_font7.Name = "button_font7";
            this.button_font7.Size = new System.Drawing.Size(19, 27);
            this.button_font7.TabIndex = 54;
            this.button_font7.Text = "X";
            this.button_font7.UseVisualStyleBackColor = true;
            this.button_font7.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Num3
            // 
            this.textBox_Num3.Location = new System.Drawing.Point(135, 94);
            this.textBox_Num3.Name = "textBox_Num3";
            this.textBox_Num3.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num3.TabIndex = 62;
            this.textBox_Num3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Hight7
            // 
            this.textBox_Hight7.Location = new System.Drawing.Point(81, 202);
            this.textBox_Hight7.Name = "textBox_Hight7";
            this.textBox_Hight7.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight7.TabIndex = 56;
            this.textBox_Hight7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Num2
            // 
            this.textBox_Num2.Location = new System.Drawing.Point(135, 67);
            this.textBox_Num2.Name = "textBox_Num2";
            this.textBox_Num2.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num2.TabIndex = 61;
            this.textBox_Num2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width7
            // 
            this.textBox_Width7.Location = new System.Drawing.Point(5, 202);
            this.textBox_Width7.Name = "textBox_Width7";
            this.textBox_Width7.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width7.TabIndex = 55;
            this.textBox_Width7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Num1
            // 
            this.textBox_Num1.Location = new System.Drawing.Point(135, 40);
            this.textBox_Num1.Name = "textBox_Num1";
            this.textBox_Num1.Size = new System.Drawing.Size(51, 21);
            this.textBox_Num1.TabIndex = 60;
            this.textBox_Num1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font6
            // 
            this.button_font6.Location = new System.Drawing.Point(58, 171);
            this.button_font6.Name = "button_font6";
            this.button_font6.Size = new System.Drawing.Size(19, 27);
            this.button_font6.TabIndex = 51;
            this.button_font6.Text = "X";
            this.button_font6.UseVisualStyleBackColor = true;
            this.button_font6.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Hight6
            // 
            this.textBox_Hight6.Location = new System.Drawing.Point(81, 175);
            this.textBox_Hight6.Name = "textBox_Hight6";
            this.textBox_Hight6.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight6.TabIndex = 53;
            this.textBox_Hight6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width6
            // 
            this.textBox_Width6.Location = new System.Drawing.Point(5, 175);
            this.textBox_Width6.Name = "textBox_Width6";
            this.textBox_Width6.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width6.TabIndex = 52;
            this.textBox_Width6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font5
            // 
            this.button_font5.Location = new System.Drawing.Point(58, 144);
            this.button_font5.Name = "button_font5";
            this.button_font5.Size = new System.Drawing.Size(19, 27);
            this.button_font5.TabIndex = 48;
            this.button_font5.Text = "X";
            this.button_font5.UseVisualStyleBackColor = true;
            this.button_font5.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Hight5
            // 
            this.textBox_Hight5.Location = new System.Drawing.Point(81, 148);
            this.textBox_Hight5.Name = "textBox_Hight5";
            this.textBox_Hight5.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight5.TabIndex = 50;
            this.textBox_Hight5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width5
            // 
            this.textBox_Width5.Location = new System.Drawing.Point(5, 148);
            this.textBox_Width5.Name = "textBox_Width5";
            this.textBox_Width5.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width5.TabIndex = 49;
            this.textBox_Width5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font4
            // 
            this.button_font4.Location = new System.Drawing.Point(58, 117);
            this.button_font4.Name = "button_font4";
            this.button_font4.Size = new System.Drawing.Size(19, 27);
            this.button_font4.TabIndex = 45;
            this.button_font4.Text = "X";
            this.button_font4.UseVisualStyleBackColor = true;
            this.button_font4.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Hight4
            // 
            this.textBox_Hight4.Location = new System.Drawing.Point(81, 121);
            this.textBox_Hight4.Name = "textBox_Hight4";
            this.textBox_Hight4.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight4.TabIndex = 47;
            this.textBox_Hight4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width4
            // 
            this.textBox_Width4.Location = new System.Drawing.Point(5, 121);
            this.textBox_Width4.Name = "textBox_Width4";
            this.textBox_Width4.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width4.TabIndex = 46;
            this.textBox_Width4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font3
            // 
            this.button_font3.Location = new System.Drawing.Point(58, 90);
            this.button_font3.Name = "button_font3";
            this.button_font3.Size = new System.Drawing.Size(19, 27);
            this.button_font3.TabIndex = 42;
            this.button_font3.Text = "X";
            this.button_font3.UseVisualStyleBackColor = true;
            this.button_font3.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Hight3
            // 
            this.textBox_Hight3.Location = new System.Drawing.Point(81, 94);
            this.textBox_Hight3.Name = "textBox_Hight3";
            this.textBox_Hight3.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight3.TabIndex = 44;
            this.textBox_Hight3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width3
            // 
            this.textBox_Width3.Location = new System.Drawing.Point(5, 94);
            this.textBox_Width3.Name = "textBox_Width3";
            this.textBox_Width3.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width3.TabIndex = 43;
            this.textBox_Width3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font2
            // 
            this.button_font2.Location = new System.Drawing.Point(58, 63);
            this.button_font2.Name = "button_font2";
            this.button_font2.Size = new System.Drawing.Size(19, 27);
            this.button_font2.TabIndex = 39;
            this.button_font2.Text = "X";
            this.button_font2.UseVisualStyleBackColor = true;
            this.button_font2.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Hight2
            // 
            this.textBox_Hight2.Location = new System.Drawing.Point(81, 67);
            this.textBox_Hight2.Name = "textBox_Hight2";
            this.textBox_Hight2.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight2.TabIndex = 41;
            this.textBox_Hight2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width2
            // 
            this.textBox_Width2.Location = new System.Drawing.Point(5, 67);
            this.textBox_Width2.Name = "textBox_Width2";
            this.textBox_Width2.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width2.TabIndex = 40;
            this.textBox_Width2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_font1
            // 
            this.button_font1.Location = new System.Drawing.Point(58, 36);
            this.button_font1.Name = "button_font1";
            this.button_font1.Size = new System.Drawing.Size(19, 27);
            this.button_font1.TabIndex = 35;
            this.button_font1.Text = "X";
            this.button_font1.UseVisualStyleBackColor = true;
            this.button_font1.Click += new System.EventHandler(this.button_font_Click);
            // 
            // textBox_Hight1
            // 
            this.textBox_Hight1.Location = new System.Drawing.Point(81, 40);
            this.textBox_Hight1.Name = "textBox_Hight1";
            this.textBox_Hight1.Size = new System.Drawing.Size(51, 21);
            this.textBox_Hight1.TabIndex = 38;
            this.textBox_Hight1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_Width1
            // 
            this.textBox_Width1.Location = new System.Drawing.Point(5, 40);
            this.textBox_Width1.Name = "textBox_Width1";
            this.textBox_Width1.Size = new System.Drawing.Size(51, 21);
            this.textBox_Width1.TabIndex = 37;
            this.textBox_Width1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_outsideh
            // 
            this.textBox_outsideh.Location = new System.Drawing.Point(199, 148);
            this.textBox_outsideh.Name = "textBox_outsideh";
            this.textBox_outsideh.Size = new System.Drawing.Size(51, 21);
            this.textBox_outsideh.TabIndex = 36;
            this.textBox_outsideh.Text = "24";
            this.textBox_outsideh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_outsidew
            // 
            this.textBox_outsidew.Location = new System.Drawing.Point(323, 28);
            this.textBox_outsidew.Name = "textBox_outsidew";
            this.textBox_outsidew.Size = new System.Drawing.Size(72, 21);
            this.textBox_outsidew.TabIndex = 35;
            this.textBox_outsidew.Text = "50";
            this.textBox_outsidew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::SYD_COPY_FILE.Properties.Resources.arrows4;
            this.pictureBox5.Location = new System.Drawing.Point(251, 24);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(62, 25);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 33;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox4.Image = global::SYD_COPY_FILE.Properties.Resources.arrows2;
            this.pictureBox4.Location = new System.Drawing.Point(400, 24);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(56, 25);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 32;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SYD_COPY_FILE.Properties.Resources.arrows1;
            this.pictureBox3.Location = new System.Drawing.Point(220, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(0, 0);
            this.pictureBox3.TabIndex = 31;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SYD_COPY_FILE.Properties.Resources.arrows3;
            this.pictureBox2.Location = new System.Drawing.Point(227, 211);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(23, 60);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.textBox_insideRw);
            this.panel2.Controls.Add(this.pictureBox12);
            this.panel2.Controls.Add(this.pictureBox13);
            this.panel2.Controls.Add(this.textBox_insideRh);
            this.panel2.Controls.Add(this.pictureBox10);
            this.panel2.Controls.Add(this.pictureBox11);
            this.panel2.Controls.Add(this.button21);
            this.panel2.Controls.Add(this.textBox_insideh);
            this.panel2.Controls.Add(this.textBox_insidew);
            this.panel2.Controls.Add(this.pictureBox9);
            this.panel2.Controls.Add(this.pictureBox8);
            this.panel2.Controls.Add(this.pictureBox7);
            this.panel2.Controls.Add(this.pictureBox6);
            this.panel2.Location = new System.Drawing.Point(251, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(205, 220);
            this.panel2.TabIndex = 28;
            // 
            // textBox_insideRw
            // 
            this.textBox_insideRw.Location = new System.Drawing.Point(140, 99);
            this.textBox_insideRw.Name = "textBox_insideRw";
            this.textBox_insideRw.Size = new System.Drawing.Size(57, 21);
            this.textBox_insideRw.TabIndex = 43;
            this.textBox_insideRw.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox12.Image = global::SYD_COPY_FILE.Properties.Resources.arrows2;
            this.pictureBox12.Location = new System.Drawing.Point(180, 123);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(17, 25);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 42;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::SYD_COPY_FILE.Properties.Resources.arrows4;
            this.pictureBox13.Location = new System.Drawing.Point(139, 123);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(21, 25);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 41;
            this.pictureBox13.TabStop = false;
            // 
            // textBox_insideRh
            // 
            this.textBox_insideRh.Location = new System.Drawing.Point(108, 167);
            this.textBox_insideRh.Name = "textBox_insideRh";
            this.textBox_insideRh.Size = new System.Drawing.Size(51, 21);
            this.textBox_insideRh.TabIndex = 40;
            this.textBox_insideRh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::SYD_COPY_FILE.Properties.Resources.arrows3;
            this.pictureBox10.Location = new System.Drawing.Point(122, 194);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(23, 21);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 39;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::SYD_COPY_FILE.Properties.Resources.arrows1;
            this.pictureBox11.Location = new System.Drawing.Point(123, 144);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(23, 26);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 38;
            this.pictureBox11.TabStop = false;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(59, 72);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(81, 73);
            this.button21.TabIndex = 27;
            this.button21.Text = "cal";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // textBox_insideh
            // 
            this.textBox_insideh.Location = new System.Drawing.Point(36, 26);
            this.textBox_insideh.Name = "textBox_insideh";
            this.textBox_insideh.Size = new System.Drawing.Size(51, 21);
            this.textBox_insideh.TabIndex = 37;
            this.textBox_insideh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_insidew
            // 
            this.textBox_insidew.Location = new System.Drawing.Point(3, 88);
            this.textBox_insidew.Name = "textBox_insidew";
            this.textBox_insidew.Size = new System.Drawing.Size(57, 21);
            this.textBox_insidew.TabIndex = 36;
            this.textBox_insidew.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox9.Image = global::SYD_COPY_FILE.Properties.Resources.arrows2;
            this.pictureBox9.Location = new System.Drawing.Point(43, 62);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(17, 25);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 34;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::SYD_COPY_FILE.Properties.Resources.arrows4;
            this.pictureBox8.Location = new System.Drawing.Point(2, 62);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(21, 25);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 34;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::SYD_COPY_FILE.Properties.Resources.arrows3;
            this.pictureBox7.Location = new System.Drawing.Point(50, 53);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(23, 21);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 35;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::SYD_COPY_FILE.Properties.Resources.arrows1;
            this.pictureBox6.Location = new System.Drawing.Point(51, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(23, 26);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 34;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SYD_COPY_FILE.Properties.Resources.arrows1;
            this.pictureBox1.Location = new System.Drawing.Point(227, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 60);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // panel17
            // 
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Location = new System.Drawing.Point(196, 20);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(313, 278);
            this.panel17.TabIndex = 76;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label50);
            this.groupBox11.Controls.Add(this.groupBox13);
            this.groupBox11.Controls.Add(this.textBox55);
            this.groupBox11.Controls.Add(this.textBox58);
            this.groupBox11.Controls.Add(this.button18);
            this.groupBox11.Controls.Add(this.textBox59);
            this.groupBox11.Controls.Add(this.label51);
            this.groupBox11.Controls.Add(this.label52);
            this.groupBox11.Location = new System.Drawing.Point(1, 231);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(192, 197);
            this.groupBox11.TabIndex = 23;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "RGB";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(8, 70);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(47, 12);
            this.label50.TabIndex = 34;
            this.label50.Text = "result:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.textBoxR);
            this.groupBox13.Controls.Add(this.label58);
            this.groupBox13.Controls.Add(this.textBoxB);
            this.groupBox13.Controls.Add(this.buttonRGB);
            this.groupBox13.Controls.Add(this.label57);
            this.groupBox13.Controls.Add(this.textBoxG);
            this.groupBox13.Controls.Add(this.label56);
            this.groupBox13.Location = new System.Drawing.Point(5, 94);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(140, 100);
            this.groupBox13.TabIndex = 33;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "RGB(0~255)";
            // 
            // textBoxR
            // 
            this.textBoxR.AllowDrop = true;
            this.textBoxR.Location = new System.Drawing.Point(25, 22);
            this.textBoxR.Name = "textBoxR";
            this.textBoxR.Size = new System.Drawing.Size(39, 21);
            this.textBoxR.TabIndex = 27;
            this.textBoxR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(10, 26);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(17, 12);
            this.label58.TabIndex = 28;
            this.label58.Text = "R:";
            // 
            // textBoxB
            // 
            this.textBoxB.AllowDrop = true;
            this.textBoxB.Location = new System.Drawing.Point(25, 72);
            this.textBoxB.Name = "textBoxB";
            this.textBoxB.Size = new System.Drawing.Size(39, 21);
            this.textBoxB.TabIndex = 31;
            this.textBoxB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // buttonRGB
            // 
            this.buttonRGB.Location = new System.Drawing.Point(69, 22);
            this.buttonRGB.Name = "buttonRGB";
            this.buttonRGB.Size = new System.Drawing.Size(58, 71);
            this.buttonRGB.TabIndex = 26;
            this.buttonRGB.Text = "cal";
            this.buttonRGB.UseVisualStyleBackColor = true;
            this.buttonRGB.Click += new System.EventHandler(this.buttonRGB_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(10, 76);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(17, 12);
            this.label57.TabIndex = 32;
            this.label57.Text = "B:";
            // 
            // textBoxG
            // 
            this.textBoxG.AllowDrop = true;
            this.textBoxG.Location = new System.Drawing.Point(25, 46);
            this.textBoxG.Name = "textBoxG";
            this.textBoxG.Size = new System.Drawing.Size(39, 21);
            this.textBoxG.TabIndex = 29;
            this.textBoxG.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox_KeyPress);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(10, 50);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(17, 12);
            this.label56.TabIndex = 30;
            this.label56.Text = "G:";
            // 
            // textBox55
            // 
            this.textBox55.AllowDrop = true;
            this.textBox55.Location = new System.Drawing.Point(35, 40);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(92, 21);
            this.textBox55.TabIndex = 12;
            this.textBox55.Text = "0xc0c0c0";
            // 
            // textBox58
            // 
            this.textBox58.AllowDrop = true;
            this.textBox58.Location = new System.Drawing.Point(35, 13);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(92, 21);
            this.textBox58.TabIndex = 2;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(133, 17);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(53, 36);
            this.button18.TabIndex = 0;
            this.button18.Text = "cal";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // textBox59
            // 
            this.textBox59.AllowDrop = true;
            this.textBox59.Location = new System.Drawing.Point(50, 67);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(136, 21);
            this.textBox59.TabIndex = 9;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(8, 17);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(29, 12);
            this.label51.TabIndex = 11;
            this.label51.Text = "dec:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(8, 44);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(29, 12);
            this.label52.TabIndex = 11;
            this.label52.Text = "hex:";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.LED_result1_textBox);
            this.groupBox9.Controls.Add(this.LED_input1_textBox);
            this.groupBox9.Controls.Add(this.label_turn1);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Controls.Add(this.label38);
            this.groupBox9.Controls.Add(this.label39);
            this.groupBox9.Controls.Add(this.label40);
            this.groupBox9.Controls.Add(this.label41);
            this.groupBox9.Controls.Add(this.label42);
            this.groupBox9.Controls.Add(this.label43);
            this.groupBox9.Controls.Add(this.label44);
            this.groupBox9.Controls.Add(this.label45);
            this.groupBox9.Controls.Add(this.textBox_GPIO7);
            this.groupBox9.Controls.Add(this.textBox_GPIO6);
            this.groupBox9.Controls.Add(this.textBox_GPIO5);
            this.groupBox9.Controls.Add(this.textBox_GPIO4);
            this.groupBox9.Controls.Add(this.textBox_GPIO3);
            this.groupBox9.Controls.Add(this.textBox_GPIO2);
            this.groupBox9.Controls.Add(this.textBox_GPIO1);
            this.groupBox9.Controls.Add(this.textBox_GPIO0);
            this.groupBox9.Controls.Add(this.label46);
            this.groupBox9.Location = new System.Drawing.Point(3, 117);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(541, 108);
            this.groupBox9.TabIndex = 22;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "LED_Display_U8toU32";
            // 
            // LED_result1_textBox
            // 
            this.LED_result1_textBox.AllowDrop = true;
            this.LED_result1_textBox.Location = new System.Drawing.Point(116, 69);
            this.LED_result1_textBox.Name = "LED_result1_textBox";
            this.LED_result1_textBox.Size = new System.Drawing.Size(92, 21);
            this.LED_result1_textBox.TabIndex = 44;
            // 
            // LED_input1_textBox
            // 
            this.LED_input1_textBox.AllowDrop = true;
            this.LED_input1_textBox.Location = new System.Drawing.Point(10, 69);
            this.LED_input1_textBox.Name = "LED_input1_textBox";
            this.LED_input1_textBox.Size = new System.Drawing.Size(92, 21);
            this.LED_input1_textBox.TabIndex = 43;
            this.LED_input1_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LED_input1_textBox_keydown);
            // 
            // label_turn1
            // 
            this.label_turn1.AutoSize = true;
            this.label_turn1.Font = new System.Drawing.Font("宋体", 15F);
            this.label_turn1.Location = new System.Drawing.Point(101, 70);
            this.label_turn1.Name = "label_turn1";
            this.label_turn1.Size = new System.Drawing.Size(19, 20);
            this.label_turn1.TabIndex = 42;
            this.label_turn1.Text = ">";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("宋体", 12F);
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(320, 22);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(40, 16);
            this.label37.TabIndex = 40;
            this.label37.Text = " DP ";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("宋体", 12F);
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(298, 22);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(16, 16);
            this.label38.TabIndex = 39;
            this.label38.Text = "G";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("宋体", 12F);
            this.label39.ForeColor = System.Drawing.Color.Red;
            this.label39.Location = new System.Drawing.Point(270, 22);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(16, 16);
            this.label39.TabIndex = 38;
            this.label39.Text = "F";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("宋体", 12F);
            this.label40.ForeColor = System.Drawing.Color.Red;
            this.label40.Location = new System.Drawing.Point(236, 22);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(16, 16);
            this.label40.TabIndex = 37;
            this.label40.Text = "E";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("宋体", 12F);
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(204, 22);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(16, 16);
            this.label41.TabIndex = 36;
            this.label41.Text = "D";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("宋体", 12F);
            this.label42.ForeColor = System.Drawing.Color.Red;
            this.label42.Location = new System.Drawing.Point(168, 22);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(16, 16);
            this.label42.TabIndex = 35;
            this.label42.Text = "C";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("宋体", 12F);
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(140, 22);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(16, 16);
            this.label43.TabIndex = 34;
            this.label43.Text = "B";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("宋体", 12F);
            this.label44.ForeColor = System.Drawing.Color.Red;
            this.label44.Location = new System.Drawing.Point(106, 22);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(16, 16);
            this.label44.TabIndex = 33;
            this.label44.Text = "A";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(21, 26);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(71, 12);
            this.label45.TabIndex = 32;
            this.label45.Text = "数码管管脚:";
            // 
            // textBox_GPIO7
            // 
            this.textBox_GPIO7.AllowDrop = true;
            this.textBox_GPIO7.Location = new System.Drawing.Point(330, 44);
            this.textBox_GPIO7.Name = "textBox_GPIO7";
            this.textBox_GPIO7.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO7.TabIndex = 31;
            // 
            // textBox_GPIO6
            // 
            this.textBox_GPIO6.AllowDrop = true;
            this.textBox_GPIO6.Location = new System.Drawing.Point(297, 44);
            this.textBox_GPIO6.Name = "textBox_GPIO6";
            this.textBox_GPIO6.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO6.TabIndex = 30;
            this.textBox_GPIO6.Text = "10";
            // 
            // textBox_GPIO5
            // 
            this.textBox_GPIO5.AllowDrop = true;
            this.textBox_GPIO5.Location = new System.Drawing.Point(266, 44);
            this.textBox_GPIO5.Name = "textBox_GPIO5";
            this.textBox_GPIO5.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO5.TabIndex = 29;
            this.textBox_GPIO5.Text = "1";
            // 
            // textBox_GPIO4
            // 
            this.textBox_GPIO4.AllowDrop = true;
            this.textBox_GPIO4.Location = new System.Drawing.Point(233, 44);
            this.textBox_GPIO4.Name = "textBox_GPIO4";
            this.textBox_GPIO4.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO4.TabIndex = 28;
            this.textBox_GPIO4.Text = "3";
            // 
            // textBox_GPIO3
            // 
            this.textBox_GPIO3.AllowDrop = true;
            this.textBox_GPIO3.Location = new System.Drawing.Point(201, 44);
            this.textBox_GPIO3.Name = "textBox_GPIO3";
            this.textBox_GPIO3.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO3.TabIndex = 27;
            this.textBox_GPIO3.Text = "11";
            // 
            // textBox_GPIO2
            // 
            this.textBox_GPIO2.AllowDrop = true;
            this.textBox_GPIO2.Location = new System.Drawing.Point(168, 44);
            this.textBox_GPIO2.Name = "textBox_GPIO2";
            this.textBox_GPIO2.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO2.TabIndex = 26;
            this.textBox_GPIO2.Text = "8";
            // 
            // textBox_GPIO1
            // 
            this.textBox_GPIO1.AllowDrop = true;
            this.textBox_GPIO1.Location = new System.Drawing.Point(137, 44);
            this.textBox_GPIO1.Name = "textBox_GPIO1";
            this.textBox_GPIO1.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO1.TabIndex = 25;
            this.textBox_GPIO1.Text = "9";
            // 
            // textBox_GPIO0
            // 
            this.textBox_GPIO0.AllowDrop = true;
            this.textBox_GPIO0.Location = new System.Drawing.Point(104, 44);
            this.textBox_GPIO0.Name = "textBox_GPIO0";
            this.textBox_GPIO0.Size = new System.Drawing.Size(19, 21);
            this.textBox_GPIO0.TabIndex = 23;
            this.textBox_GPIO0.Text = "4";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(6, 47);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(95, 12);
            this.label46.TabIndex = 24;
            this.label46.Text = "对应的GPIO管脚:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.panel15);
            this.groupBox8.Controls.Add(this.label35);
            this.groupBox8.Controls.Add(this.textBox52);
            this.groupBox8.Controls.Add(this.button17);
            this.groupBox8.Controls.Add(this.textBox53);
            this.groupBox8.Controls.Add(this.bit_mask_result);
            this.groupBox8.Controls.Add(this.label36);
            this.groupBox8.Location = new System.Drawing.Point(3, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(744, 105);
            this.groupBox8.TabIndex = 3;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "bit_mask_U8toU32";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.button16);
            this.panel15.Controls.Add(this.panel5);
            this.panel15.Controls.Add(this.panel11);
            this.panel15.Controls.Add(this.panel1);
            this.panel15.Controls.Add(this.panel14);
            this.panel15.Controls.Add(this.panel3);
            this.panel15.Controls.Add(this.panel6);
            this.panel15.Controls.Add(this.panel4);
            this.panel15.Controls.Add(this.panel8);
            this.panel15.Location = new System.Drawing.Point(8, 20);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(729, 46);
            this.panel15.TabIndex = 62;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(650, 0);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 43);
            this.button16.TabIndex = 63;
            this.button16.Text = "Generate";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.bitmask_checkbox_Click);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Controls.Add(this.BIT_MARK8);
            this.panel5.Controls.Add(this.BIT_MARK11);
            this.panel5.Controls.Add(this.BIT_MARK10);
            this.panel5.Controls.Add(this.BIT_MARK9);
            this.panel5.Location = new System.Drawing.Point(405, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(80, 39);
            this.panel5.TabIndex = 59;
            // 
            // panel9
            // 
            this.panel9.Location = new System.Drawing.Point(80, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(80, 39);
            this.panel9.TabIndex = 60;
            // 
            // panel10
            // 
            this.panel10.Location = new System.Drawing.Point(158, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(80, 39);
            this.panel10.TabIndex = 61;
            // 
            // BIT_MARK8
            // 
            this.BIT_MARK8.AutoSize = true;
            this.BIT_MARK8.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK8.Checked = true;
            this.BIT_MARK8.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BIT_MARK8.Location = new System.Drawing.Point(61, 6);
            this.BIT_MARK8.Name = "BIT_MARK8";
            this.BIT_MARK8.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK8.TabIndex = 47;
            this.BIT_MARK8.Text = "8";
            this.BIT_MARK8.UseVisualStyleBackColor = true;
            this.BIT_MARK8.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK11
            // 
            this.BIT_MARK11.AutoSize = true;
            this.BIT_MARK11.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK11.Checked = true;
            this.BIT_MARK11.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BIT_MARK11.Location = new System.Drawing.Point(6, 6);
            this.BIT_MARK11.Name = "BIT_MARK11";
            this.BIT_MARK11.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK11.TabIndex = 44;
            this.BIT_MARK11.Text = "11";
            this.BIT_MARK11.UseVisualStyleBackColor = true;
            this.BIT_MARK11.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK10
            // 
            this.BIT_MARK10.AutoSize = true;
            this.BIT_MARK10.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK10.Checked = true;
            this.BIT_MARK10.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BIT_MARK10.Location = new System.Drawing.Point(25, 6);
            this.BIT_MARK10.Name = "BIT_MARK10";
            this.BIT_MARK10.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK10.TabIndex = 45;
            this.BIT_MARK10.Text = "10";
            this.BIT_MARK10.UseVisualStyleBackColor = true;
            this.BIT_MARK10.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK9
            // 
            this.BIT_MARK9.AutoSize = true;
            this.BIT_MARK9.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK9.Checked = true;
            this.BIT_MARK9.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BIT_MARK9.Location = new System.Drawing.Point(46, 6);
            this.BIT_MARK9.Name = "BIT_MARK9";
            this.BIT_MARK9.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK9.TabIndex = 46;
            this.BIT_MARK9.Text = "9";
            this.BIT_MARK9.UseVisualStyleBackColor = true;
            this.BIT_MARK9.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Controls.Add(this.BIT_MARK4);
            this.panel11.Controls.Add(this.BIT_MARK7);
            this.panel11.Controls.Add(this.BIT_MARK6);
            this.panel11.Controls.Add(this.BIT_MARK5);
            this.panel11.Location = new System.Drawing.Point(487, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(80, 39);
            this.panel11.TabIndex = 60;
            // 
            // panel12
            // 
            this.panel12.Location = new System.Drawing.Point(80, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(80, 39);
            this.panel12.TabIndex = 61;
            // 
            // BIT_MARK4
            // 
            this.BIT_MARK4.AutoSize = true;
            this.BIT_MARK4.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK4.Checked = true;
            this.BIT_MARK4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BIT_MARK4.Location = new System.Drawing.Point(59, 6);
            this.BIT_MARK4.Name = "BIT_MARK4";
            this.BIT_MARK4.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK4.TabIndex = 51;
            this.BIT_MARK4.Text = "4";
            this.BIT_MARK4.UseVisualStyleBackColor = true;
            this.BIT_MARK4.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK7
            // 
            this.BIT_MARK7.AutoSize = true;
            this.BIT_MARK7.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK7.Location = new System.Drawing.Point(4, 6);
            this.BIT_MARK7.Name = "BIT_MARK7";
            this.BIT_MARK7.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK7.TabIndex = 48;
            this.BIT_MARK7.Text = "7";
            this.BIT_MARK7.UseVisualStyleBackColor = true;
            this.BIT_MARK7.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK6
            // 
            this.BIT_MARK6.AutoSize = true;
            this.BIT_MARK6.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK6.Location = new System.Drawing.Point(23, 6);
            this.BIT_MARK6.Name = "BIT_MARK6";
            this.BIT_MARK6.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK6.TabIndex = 49;
            this.BIT_MARK6.Text = "6";
            this.BIT_MARK6.UseVisualStyleBackColor = true;
            this.BIT_MARK6.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK5
            // 
            this.BIT_MARK5.AutoSize = true;
            this.BIT_MARK5.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK5.Location = new System.Drawing.Point(40, 6);
            this.BIT_MARK5.Name = "BIT_MARK5";
            this.BIT_MARK5.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK5.TabIndex = 50;
            this.BIT_MARK5.Text = "5";
            this.BIT_MARK5.UseVisualStyleBackColor = true;
            this.BIT_MARK5.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.BIT_MARK28);
            this.panel1.Controls.Add(this.BIT_MARK31);
            this.panel1.Controls.Add(this.BIT_MARK30);
            this.panel1.Controls.Add(this.BIT_MARK29);
            this.panel1.Location = new System.Drawing.Point(1, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(85, 39);
            this.panel1.TabIndex = 0;
            // 
            // BIT_MARK28
            // 
            this.BIT_MARK28.AutoSize = true;
            this.BIT_MARK28.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK28.Location = new System.Drawing.Point(60, 6);
            this.BIT_MARK28.Name = "BIT_MARK28";
            this.BIT_MARK28.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK28.TabIndex = 27;
            this.BIT_MARK28.Text = "28";
            this.BIT_MARK28.UseVisualStyleBackColor = true;
            this.BIT_MARK28.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK31
            // 
            this.BIT_MARK31.AutoSize = true;
            this.BIT_MARK31.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK31.Location = new System.Drawing.Point(5, 6);
            this.BIT_MARK31.Name = "BIT_MARK31";
            this.BIT_MARK31.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK31.TabIndex = 24;
            this.BIT_MARK31.Text = "31";
            this.BIT_MARK31.UseVisualStyleBackColor = true;
            this.BIT_MARK31.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK30
            // 
            this.BIT_MARK30.AutoSize = true;
            this.BIT_MARK30.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK30.Location = new System.Drawing.Point(24, 6);
            this.BIT_MARK30.Name = "BIT_MARK30";
            this.BIT_MARK30.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK30.TabIndex = 25;
            this.BIT_MARK30.Text = "30";
            this.BIT_MARK30.UseVisualStyleBackColor = true;
            this.BIT_MARK30.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK29
            // 
            this.BIT_MARK29.AutoSize = true;
            this.BIT_MARK29.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK29.Location = new System.Drawing.Point(43, 6);
            this.BIT_MARK29.Name = "BIT_MARK29";
            this.BIT_MARK29.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK29.TabIndex = 26;
            this.BIT_MARK29.Text = "29";
            this.BIT_MARK29.UseVisualStyleBackColor = true;
            this.BIT_MARK29.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.BIT_MARK0);
            this.panel14.Controls.Add(this.BIT_MARK3);
            this.panel14.Controls.Add(this.BIT_MARK2);
            this.panel14.Controls.Add(this.BIT_MARK1);
            this.panel14.Location = new System.Drawing.Point(568, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(80, 39);
            this.panel14.TabIndex = 61;
            // 
            // BIT_MARK0
            // 
            this.BIT_MARK0.AutoSize = true;
            this.BIT_MARK0.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK0.Location = new System.Drawing.Point(61, 6);
            this.BIT_MARK0.Name = "BIT_MARK0";
            this.BIT_MARK0.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK0.TabIndex = 55;
            this.BIT_MARK0.Text = "0";
            this.BIT_MARK0.UseVisualStyleBackColor = true;
            this.BIT_MARK0.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK3
            // 
            this.BIT_MARK3.AutoSize = true;
            this.BIT_MARK3.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK3.Checked = true;
            this.BIT_MARK3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BIT_MARK3.Location = new System.Drawing.Point(6, 6);
            this.BIT_MARK3.Name = "BIT_MARK3";
            this.BIT_MARK3.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK3.TabIndex = 52;
            this.BIT_MARK3.Text = "3";
            this.BIT_MARK3.UseVisualStyleBackColor = true;
            this.BIT_MARK3.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK2
            // 
            this.BIT_MARK2.AutoSize = true;
            this.BIT_MARK2.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK2.Location = new System.Drawing.Point(25, 6);
            this.BIT_MARK2.Name = "BIT_MARK2";
            this.BIT_MARK2.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK2.TabIndex = 53;
            this.BIT_MARK2.Text = "2";
            this.BIT_MARK2.UseVisualStyleBackColor = true;
            this.BIT_MARK2.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK1
            // 
            this.BIT_MARK1.AutoSize = true;
            this.BIT_MARK1.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK1.Checked = true;
            this.BIT_MARK1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.BIT_MARK1.Location = new System.Drawing.Point(42, 6);
            this.BIT_MARK1.Name = "BIT_MARK1";
            this.BIT_MARK1.Size = new System.Drawing.Size(15, 30);
            this.BIT_MARK1.TabIndex = 54;
            this.BIT_MARK1.Text = "1";
            this.BIT_MARK1.UseVisualStyleBackColor = true;
            this.BIT_MARK1.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.BIT_MARK27);
            this.panel3.Controls.Add(this.BIT_MARK26);
            this.panel3.Controls.Add(this.BIT_MARK25);
            this.panel3.Controls.Add(this.BIT_MARK24);
            this.panel3.Location = new System.Drawing.Point(89, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(77, 39);
            this.panel3.TabIndex = 57;
            // 
            // BIT_MARK27
            // 
            this.BIT_MARK27.AutoSize = true;
            this.BIT_MARK27.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK27.Location = new System.Drawing.Point(1, 6);
            this.BIT_MARK27.Name = "BIT_MARK27";
            this.BIT_MARK27.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK27.TabIndex = 28;
            this.BIT_MARK27.Text = "27";
            this.BIT_MARK27.UseVisualStyleBackColor = true;
            this.BIT_MARK27.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK26
            // 
            this.BIT_MARK26.AutoSize = true;
            this.BIT_MARK26.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK26.Location = new System.Drawing.Point(20, 6);
            this.BIT_MARK26.Name = "BIT_MARK26";
            this.BIT_MARK26.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK26.TabIndex = 29;
            this.BIT_MARK26.Text = "26";
            this.BIT_MARK26.UseVisualStyleBackColor = true;
            this.BIT_MARK26.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK25
            // 
            this.BIT_MARK25.AutoSize = true;
            this.BIT_MARK25.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK25.Location = new System.Drawing.Point(38, 6);
            this.BIT_MARK25.Name = "BIT_MARK25";
            this.BIT_MARK25.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK25.TabIndex = 30;
            this.BIT_MARK25.Text = "25";
            this.BIT_MARK25.UseVisualStyleBackColor = true;
            this.BIT_MARK25.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK24
            // 
            this.BIT_MARK24.AutoSize = true;
            this.BIT_MARK24.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK24.Location = new System.Drawing.Point(56, 6);
            this.BIT_MARK24.Name = "BIT_MARK24";
            this.BIT_MARK24.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK24.TabIndex = 24;
            this.BIT_MARK24.Text = "24";
            this.BIT_MARK24.UseVisualStyleBackColor = true;
            this.BIT_MARK24.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.BIT_MARK12);
            this.panel6.Controls.Add(this.BIT_MARK15);
            this.panel6.Controls.Add(this.BIT_MARK14);
            this.panel6.Controls.Add(this.BIT_MARK13);
            this.panel6.Location = new System.Drawing.Point(324, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(80, 39);
            this.panel6.TabIndex = 57;
            // 
            // BIT_MARK12
            // 
            this.BIT_MARK12.AutoSize = true;
            this.BIT_MARK12.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK12.Location = new System.Drawing.Point(56, 6);
            this.BIT_MARK12.Name = "BIT_MARK12";
            this.BIT_MARK12.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK12.TabIndex = 43;
            this.BIT_MARK12.Text = "12";
            this.BIT_MARK12.UseVisualStyleBackColor = true;
            this.BIT_MARK12.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK15
            // 
            this.BIT_MARK15.AutoSize = true;
            this.BIT_MARK15.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK15.Location = new System.Drawing.Point(1, 6);
            this.BIT_MARK15.Name = "BIT_MARK15";
            this.BIT_MARK15.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK15.TabIndex = 40;
            this.BIT_MARK15.Text = "15";
            this.BIT_MARK15.UseVisualStyleBackColor = true;
            this.BIT_MARK15.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK14
            // 
            this.BIT_MARK14.AutoSize = true;
            this.BIT_MARK14.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK14.Location = new System.Drawing.Point(20, 6);
            this.BIT_MARK14.Name = "BIT_MARK14";
            this.BIT_MARK14.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK14.TabIndex = 41;
            this.BIT_MARK14.Text = "14";
            this.BIT_MARK14.UseVisualStyleBackColor = true;
            this.BIT_MARK14.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK13
            // 
            this.BIT_MARK13.AutoSize = true;
            this.BIT_MARK13.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK13.Location = new System.Drawing.Point(38, 6);
            this.BIT_MARK13.Name = "BIT_MARK13";
            this.BIT_MARK13.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK13.TabIndex = 42;
            this.BIT_MARK13.Text = "13";
            this.BIT_MARK13.UseVisualStyleBackColor = true;
            this.BIT_MARK13.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.BIT_MARK16);
            this.panel4.Controls.Add(this.BIT_MARK19);
            this.panel4.Controls.Add(this.BIT_MARK18);
            this.panel4.Controls.Add(this.BIT_MARK17);
            this.panel4.Location = new System.Drawing.Point(250, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(73, 39);
            this.panel4.TabIndex = 58;
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(80, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(80, 39);
            this.panel7.TabIndex = 57;
            // 
            // BIT_MARK16
            // 
            this.BIT_MARK16.AutoSize = true;
            this.BIT_MARK16.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK16.Location = new System.Drawing.Point(56, 6);
            this.BIT_MARK16.Name = "BIT_MARK16";
            this.BIT_MARK16.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK16.TabIndex = 39;
            this.BIT_MARK16.Text = "16";
            this.BIT_MARK16.UseVisualStyleBackColor = true;
            this.BIT_MARK16.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK19
            // 
            this.BIT_MARK19.AutoSize = true;
            this.BIT_MARK19.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK19.Location = new System.Drawing.Point(1, 6);
            this.BIT_MARK19.Name = "BIT_MARK19";
            this.BIT_MARK19.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK19.TabIndex = 36;
            this.BIT_MARK19.Text = "19";
            this.BIT_MARK19.UseVisualStyleBackColor = true;
            this.BIT_MARK19.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK18
            // 
            this.BIT_MARK18.AutoSize = true;
            this.BIT_MARK18.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK18.Location = new System.Drawing.Point(20, 6);
            this.BIT_MARK18.Name = "BIT_MARK18";
            this.BIT_MARK18.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK18.TabIndex = 37;
            this.BIT_MARK18.Text = "18";
            this.BIT_MARK18.UseVisualStyleBackColor = true;
            this.BIT_MARK18.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK17
            // 
            this.BIT_MARK17.AutoSize = true;
            this.BIT_MARK17.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK17.Location = new System.Drawing.Point(38, 6);
            this.BIT_MARK17.Name = "BIT_MARK17";
            this.BIT_MARK17.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK17.TabIndex = 38;
            this.BIT_MARK17.Text = "17";
            this.BIT_MARK17.UseVisualStyleBackColor = true;
            this.BIT_MARK17.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.BIT_MARK23);
            this.panel8.Controls.Add(this.BIT_MARK22);
            this.panel8.Controls.Add(this.BIT_MARK21);
            this.panel8.Controls.Add(this.BIT_MARK20);
            this.panel8.Location = new System.Drawing.Point(168, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(80, 39);
            this.panel8.TabIndex = 57;
            // 
            // BIT_MARK23
            // 
            this.BIT_MARK23.AutoSize = true;
            this.BIT_MARK23.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK23.Location = new System.Drawing.Point(3, 6);
            this.BIT_MARK23.Name = "BIT_MARK23";
            this.BIT_MARK23.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK23.TabIndex = 23;
            this.BIT_MARK23.Text = "23";
            this.BIT_MARK23.UseVisualStyleBackColor = true;
            this.BIT_MARK23.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK22
            // 
            this.BIT_MARK22.AutoSize = true;
            this.BIT_MARK22.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK22.Location = new System.Drawing.Point(22, 6);
            this.BIT_MARK22.Name = "BIT_MARK22";
            this.BIT_MARK22.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK22.TabIndex = 33;
            this.BIT_MARK22.Text = "22";
            this.BIT_MARK22.UseVisualStyleBackColor = true;
            this.BIT_MARK22.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK21
            // 
            this.BIT_MARK21.AutoSize = true;
            this.BIT_MARK21.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK21.Location = new System.Drawing.Point(40, 6);
            this.BIT_MARK21.Name = "BIT_MARK21";
            this.BIT_MARK21.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK21.TabIndex = 34;
            this.BIT_MARK21.Text = "21";
            this.BIT_MARK21.UseVisualStyleBackColor = true;
            this.BIT_MARK21.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // BIT_MARK20
            // 
            this.BIT_MARK20.AutoSize = true;
            this.BIT_MARK20.CheckAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BIT_MARK20.Location = new System.Drawing.Point(58, 6);
            this.BIT_MARK20.Name = "BIT_MARK20";
            this.BIT_MARK20.Size = new System.Drawing.Size(21, 30);
            this.BIT_MARK20.TabIndex = 35;
            this.BIT_MARK20.Text = "20";
            this.BIT_MARK20.UseVisualStyleBackColor = true;
            this.BIT_MARK20.CheckStateChanged += new System.EventHandler(this.BIT_MARK_CheckStateChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(131, 78);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(59, 12);
            this.label35.TabIndex = 22;
            this.label35.Text = "BIT_Mask:";
            // 
            // textBox52
            // 
            this.textBox52.AllowDrop = true;
            this.textBox52.Location = new System.Drawing.Point(31, 75);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(92, 21);
            this.textBox52.TabIndex = 2;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(285, 73);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(53, 22);
            this.button17.TabIndex = 0;
            this.button17.Text = "cal";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // textBox53
            // 
            this.textBox53.AllowDrop = true;
            this.textBox53.Location = new System.Drawing.Point(344, 74);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(118, 21);
            this.textBox53.TabIndex = 9;
            // 
            // bit_mask_result
            // 
            this.bit_mask_result.AllowDrop = true;
            this.bit_mask_result.Location = new System.Drawing.Point(188, 74);
            this.bit_mask_result.Name = "bit_mask_result";
            this.bit_mask_result.Size = new System.Drawing.Size(91, 21);
            this.bit_mask_result.TabIndex = 10;
            this.bit_mask_result.Text = "0x00000F1A";
            this.bit_mask_result.KeyDown += new System.Windows.Forms.KeyEventHandler(this.bit_mask_result_KeyDown);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(4, 79);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 12);
            this.label36.TabIndex = 11;
            this.label36.Text = "hex:";
            // 
            // tabPage2
            // 
            this.tabPage2.AllowDrop = true;
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.groupBox20);
            this.tabPage2.Controls.Add(this.groupBox18);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(757, 552);
            this.tabPage2.TabIndex = 2;
            this.tabPage2.Text = "BLE";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.button29);
            this.groupBox20.Controls.Add(this.textBox84);
            this.groupBox20.Location = new System.Drawing.Point(1, 157);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(751, 97);
            this.groupBox20.TabIndex = 25;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "BLE LL_Data Difference";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(687, 12);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(60, 22);
            this.button29.TabIndex = 28;
            this.button29.Text = "cal";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // textBox84
            // 
            this.textBox84.AllowDrop = true;
            this.textBox84.Location = new System.Drawing.Point(6, 13);
            this.textBox84.Multiline = true;
            this.textBox84.Name = "textBox84";
            this.textBox84.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.textBox84.Size = new System.Drawing.Size(679, 78);
            this.textBox84.TabIndex = 23;
            this.textBox84.Text = resources.GetString("textBox84.Text");
            this.textBox84.WordWrap = false;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.textBox81);
            this.groupBox18.Controls.Add(this.groupBox19);
            this.groupBox18.Controls.Add(this.label77);
            this.groupBox18.Controls.Add(this.textBox78);
            this.groupBox18.Controls.Add(this.label73);
            this.groupBox18.Controls.Add(this.button28);
            this.groupBox18.Controls.Add(this.textBox80);
            this.groupBox18.Location = new System.Drawing.Point(0, 105);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(508, 50);
            this.groupBox18.TabIndex = 24;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "BLE transmission speed";
            // 
            // textBox81
            // 
            this.textBox81.AllowDrop = true;
            this.textBox81.Location = new System.Drawing.Point(221, 19);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(104, 21);
            this.textBox81.TabIndex = 27;
            this.textBox81.Text = "00:00:02:723206";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.textBox70);
            this.groupBox19.Controls.Add(this.textBox72);
            this.groupBox19.Controls.Add(this.label69);
            this.groupBox19.Controls.Add(this.label70);
            this.groupBox19.Controls.Add(this.button27);
            this.groupBox19.Controls.Add(this.textBox74);
            this.groupBox19.Location = new System.Drawing.Point(0, 51);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(384, 50);
            this.groupBox19.TabIndex = 25;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "BLE Frame Time Difference(dec)";
            // 
            // textBox70
            // 
            this.textBox70.AllowDrop = true;
            this.textBox70.Location = new System.Drawing.Point(94, 20);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(38, 21);
            this.textBox70.TabIndex = 23;
            // 
            // textBox72
            // 
            this.textBox72.AllowDrop = true;
            this.textBox72.Location = new System.Drawing.Point(218, 19);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(38, 21);
            this.textBox72.TabIndex = 21;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(8, 22);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(89, 12);
            this.label69.TabIndex = 24;
            this.label69.Text = "Receive Timer:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(142, 23);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(71, 12);
            this.label70.TabIndex = 22;
            this.label70.Text = "Frame Size:";
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(269, 19);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(53, 22);
            this.button27.TabIndex = 0;
            this.button27.Text = "cal";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // textBox74
            // 
            this.textBox74.AllowDrop = true;
            this.textBox74.Location = new System.Drawing.Point(330, 20);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(38, 21);
            this.textBox74.TabIndex = 9;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(137, 22);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(83, 12);
            this.label77.TabIndex = 26;
            this.label77.Text = "Elapsed time:";
            // 
            // textBox78
            // 
            this.textBox78.AllowDrop = true;
            this.textBox78.Location = new System.Drawing.Point(89, 20);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(48, 21);
            this.textBox78.TabIndex = 23;
            this.textBox78.Text = "1000";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(8, 22);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(83, 12);
            this.label73.TabIndex = 24;
            this.label73.Text = "total Packet:";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(329, 19);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(53, 22);
            this.button28.TabIndex = 0;
            this.button28.Text = "cal";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // textBox80
            // 
            this.textBox80.AllowDrop = true;
            this.textBox80.Location = new System.Drawing.Point(390, 20);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(113, 21);
            this.textBox80.TabIndex = 9;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBox18);
            this.groupBox6.Controls.Add(this.textBox17);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.textBox16);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.textBox15);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.textBox13);
            this.groupBox6.Controls.Add(this.button5);
            this.groupBox6.Controls.Add(this.textBox14);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Location = new System.Drawing.Point(0, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(604, 50);
            this.groupBox6.TabIndex = 22;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "latency_cal";
            // 
            // textBox18
            // 
            this.textBox18.AllowDrop = true;
            this.textBox18.Location = new System.Drawing.Point(61, 19);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(38, 21);
            this.textBox18.TabIndex = 23;
            // 
            // textBox17
            // 
            this.textBox17.AllowDrop = true;
            this.textBox17.Location = new System.Drawing.Point(168, 19);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(38, 21);
            this.textBox17.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 12);
            this.label11.TabIndex = 24;
            this.label11.Text = "EvtCnt:";
            // 
            // textBox16
            // 
            this.textBox16.AllowDrop = true;
            this.textBox16.Location = new System.Drawing.Point(453, 19);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(38, 21);
            this.textBox16.TabIndex = 23;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(109, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 22;
            this.label10.Text = "Instant:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(394, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 24;
            this.label9.Text = "latency:";
            // 
            // textBox15
            // 
            this.textBox15.AllowDrop = true;
            this.textBox15.Location = new System.Drawing.Point(346, 19);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(38, 21);
            this.textBox15.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(305, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 12);
            this.label8.TabIndex = 22;
            this.label8.Text = "nitv:";
            // 
            // textBox13
            // 
            this.textBox13.AllowDrop = true;
            this.textBox13.Location = new System.Drawing.Point(257, 19);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(38, 21);
            this.textBox13.TabIndex = 2;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(499, 18);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(53, 22);
            this.button5.TabIndex = 0;
            this.button5.Text = "cal";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox14
            // 
            this.textBox14.AllowDrop = true;
            this.textBox14.Location = new System.Drawing.Point(560, 19);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(38, 21);
            this.textBox14.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(216, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 11;
            this.label7.Text = "pitv:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox17);
            this.groupBox2.Controls.Add(this.textBox19);
            this.groupBox2.Controls.Add(this.textBox20);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.textBox24);
            this.groupBox2.Location = new System.Drawing.Point(2, 54);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(384, 50);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "BLE Frame Time Difference(dec)";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.textBox66);
            this.groupBox17.Controls.Add(this.textBox67);
            this.groupBox17.Controls.Add(this.label67);
            this.groupBox17.Controls.Add(this.label68);
            this.groupBox17.Controls.Add(this.button24);
            this.groupBox17.Controls.Add(this.textBox68);
            this.groupBox17.Location = new System.Drawing.Point(0, 51);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(384, 50);
            this.groupBox17.TabIndex = 25;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "BLE Frame Time Difference(dec)";
            // 
            // textBox66
            // 
            this.textBox66.AllowDrop = true;
            this.textBox66.Location = new System.Drawing.Point(94, 20);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(38, 21);
            this.textBox66.TabIndex = 23;
            // 
            // textBox67
            // 
            this.textBox67.AllowDrop = true;
            this.textBox67.Location = new System.Drawing.Point(218, 19);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(38, 21);
            this.textBox67.TabIndex = 21;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(8, 22);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(89, 12);
            this.label67.TabIndex = 24;
            this.label67.Text = "Receive Timer:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(142, 23);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(71, 12);
            this.label68.TabIndex = 22;
            this.label68.Text = "Frame Size:";
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(269, 19);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(53, 22);
            this.button24.TabIndex = 0;
            this.button24.Text = "cal";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // textBox68
            // 
            this.textBox68.AllowDrop = true;
            this.textBox68.Location = new System.Drawing.Point(330, 20);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(38, 21);
            this.textBox68.TabIndex = 9;
            // 
            // textBox19
            // 
            this.textBox19.AllowDrop = true;
            this.textBox19.Location = new System.Drawing.Point(94, 20);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(38, 21);
            this.textBox19.TabIndex = 23;
            this.textBox19.Text = "325";
            // 
            // textBox20
            // 
            this.textBox20.AllowDrop = true;
            this.textBox20.Location = new System.Drawing.Point(218, 19);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(38, 21);
            this.textBox20.TabIndex = 21;
            this.textBox20.Text = "30";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 12);
            this.label12.TabIndex = 24;
            this.label12.Text = "Receive Timer:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(142, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 12);
            this.label13.TabIndex = 22;
            this.label13.Text = "Frame Size:";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(269, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(53, 22);
            this.button6.TabIndex = 0;
            this.button6.Text = "cal";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox24
            // 
            this.textBox24.AllowDrop = true;
            this.textBox24.Location = new System.Drawing.Point(330, 20);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(38, 21);
            this.textBox24.TabIndex = 9;
            this.textBox24.Text = "149";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox10);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(757, 552);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "C";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label47);
            this.groupBox10.Controls.Add(this.textBox12);
            this.groupBox10.Controls.Add(this.button19);
            this.groupBox10.Controls.Add(this.textBox54);
            this.groupBox10.Controls.Add(this.label48);
            this.groupBox10.Controls.Add(this.label49);
            this.groupBox10.Location = new System.Drawing.Point(6, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(746, 574);
            this.groupBox10.TabIndex = 33;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "批量差值";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 17);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(89, 12);
            this.label47.TabIndex = 27;
            this.label47.Text = "INPUT(uint8 a)";
            // 
            // textBox12
            // 
            this.textBox12.AllowDrop = true;
            this.textBox12.Location = new System.Drawing.Point(8, 32);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox12.Size = new System.Drawing.Size(337, 510);
            this.textBox12.TabIndex = 25;
            this.textBox12.Text = resources.GetString("textBox12.Text");
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(396, 7);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(35, 22);
            this.button19.TabIndex = 30;
            this.button19.Text = "cal";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // textBox54
            // 
            this.textBox54.AllowDrop = true;
            this.textBox54.Location = new System.Drawing.Point(351, 32);
            this.textBox54.Multiline = true;
            this.textBox54.Name = "textBox54";
            this.textBox54.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox54.Size = new System.Drawing.Size(392, 510);
            this.textBox54.TabIndex = 26;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(339, 17);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(17, 12);
            this.label48.TabIndex = 29;
            this.label48.Text = ">>";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(455, 17);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(41, 12);
            this.label49.TabIndex = 28;
            this.label49.Text = "RESULT";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button30);
            this.tabPage4.Controls.Add(this.label84);
            this.tabPage4.Controls.Add(this.comboBox_mode);
            this.tabPage4.Controls.Add(this.button_clear);
            this.tabPage4.Controls.Add(this.draw);
            this.tabPage4.Controls.Add(this.groupBox23);
            this.tabPage4.Controls.Add(this.groupBox22);
            this.tabPage4.Controls.Add(this.groupBox21);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(757, 552);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Arr";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(255, 93);
            this.button30.Margin = new System.Windows.Forms.Padding(2);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(68, 22);
            this.button30.TabIndex = 32;
            this.button30.Text = "重载数据";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button_reintput_Click);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(5, 98);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(35, 12);
            this.label84.TabIndex = 29;
            this.label84.Text = "模式:";
            // 
            // comboBox_mode
            // 
            this.comboBox_mode.FormattingEnabled = true;
            this.comboBox_mode.Items.AddRange(new object[] {
            "BIN to ARR",
            "RGB palette 24BIT TO 565",
            "Font txt to bin",
            "jlink txt to array",
            "Chinese to utf8",
            "Keil memery analysis",
            "Data filled complement zero",
            "Multibyte  reversal"});
            this.comboBox_mode.Location = new System.Drawing.Point(42, 95);
            this.comboBox_mode.Name = "comboBox_mode";
            this.comboBox_mode.Size = new System.Drawing.Size(206, 20);
            this.comboBox_mode.TabIndex = 28;
            // 
            // button_clear
            // 
            this.button_clear.Location = new System.Drawing.Point(414, 92);
            this.button_clear.Margin = new System.Windows.Forms.Padding(2);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(71, 24);
            this.button_clear.TabIndex = 27;
            this.button_clear.Text = "清除";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // draw
            // 
            this.draw.Location = new System.Drawing.Point(339, 92);
            this.draw.Margin = new System.Windows.Forms.Padding(2);
            this.draw.Name = "draw";
            this.draw.Size = new System.Drawing.Size(71, 24);
            this.draw.TabIndex = 26;
            this.draw.Text = "提取";
            this.draw.UseVisualStyleBackColor = true;
            this.draw.Click += new System.EventHandler(this.draw_Click);
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.richTextBox_out);
            this.groupBox23.Location = new System.Drawing.Point(4, 411);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(753, 138);
            this.groupBox23.TabIndex = 31;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Output text";
            // 
            // richTextBox_out
            // 
            this.richTextBox_out.BackColor = System.Drawing.Color.White;
            this.richTextBox_out.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox_out.Location = new System.Drawing.Point(5, 13);
            this.richTextBox_out.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox_out.Name = "richTextBox_out";
            this.richTextBox_out.Size = new System.Drawing.Size(745, 120);
            this.richTextBox_out.TabIndex = 0;
            this.richTextBox_out.Text = "";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.textInput);
            this.groupBox22.Location = new System.Drawing.Point(2, 113);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(752, 298);
            this.groupBox22.TabIndex = 30;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Input text";
            // 
            // textInput
            // 
            this.textInput.BackColor = System.Drawing.Color.White;
            this.textInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textInput.Location = new System.Drawing.Point(5, 19);
            this.textInput.Margin = new System.Windows.Forms.Padding(2);
            this.textInput.Name = "textInput";
            this.textInput.Size = new System.Drawing.Size(747, 269);
            this.textInput.TabIndex = 0;
            this.textInput.Text = "";
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.comboBox_fonttype);
            this.groupBox21.Controls.Add(this.label76);
            this.groupBox21.Controls.Add(this.comboBox_datatype);
            this.groupBox21.Controls.Add(this.label78);
            this.groupBox21.Controls.Add(this.textBox_filesize);
            this.groupBox21.Controls.Add(this.label79);
            this.groupBox21.Controls.Add(this.label_intputsize);
            this.groupBox21.Controls.Add(this.label81);
            this.groupBox21.Controls.Add(this.label_outfilename);
            this.groupBox21.Controls.Add(this.source_file_button);
            this.groupBox21.Controls.Add(this.label83);
            this.groupBox21.Controls.Add(this.source_file_textBox);
            this.groupBox21.Location = new System.Drawing.Point(3, 3);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(751, 87);
            this.groupBox21.TabIndex = 25;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "file";
            // 
            // comboBox_fonttype
            // 
            this.comboBox_fonttype.FormattingEnabled = true;
            this.comboBox_fonttype.Items.AddRange(new object[] {
            "16X16",
            "32X32"});
            this.comboBox_fonttype.Location = new System.Drawing.Point(612, 64);
            this.comboBox_fonttype.Name = "comboBox_fonttype";
            this.comboBox_fonttype.Size = new System.Drawing.Size(73, 20);
            this.comboBox_fonttype.TabIndex = 21;
            this.comboBox_fonttype.Text = "16X16";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(552, 67);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(59, 12);
            this.label76.TabIndex = 22;
            this.label76.Text = "字库类型:";
            // 
            // comboBox_datatype
            // 
            this.comboBox_datatype.FormattingEnabled = true;
            this.comboBox_datatype.Items.AddRange(new object[] {
            "uint8",
            "uint16",
            "uint32"});
            this.comboBox_datatype.Location = new System.Drawing.Point(464, 64);
            this.comboBox_datatype.Name = "comboBox_datatype";
            this.comboBox_datatype.Size = new System.Drawing.Size(73, 20);
            this.comboBox_datatype.TabIndex = 19;
            this.comboBox_datatype.Text = "uint8";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(384, 67);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(83, 12);
            this.label78.TabIndex = 20;
            this.label78.Text = "生成数据类型:";
            // 
            // textBox_filesize
            // 
            this.textBox_filesize.AllowDrop = true;
            this.textBox_filesize.Location = new System.Drawing.Point(295, 64);
            this.textBox_filesize.Name = "textBox_filesize";
            this.textBox_filesize.Size = new System.Drawing.Size(87, 21);
            this.textBox_filesize.TabIndex = 18;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(180, 67);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(119, 12);
            this.label79.TabIndex = 16;
            this.label79.Text = "提取数组大小(Byte):";
            // 
            // label_intputsize
            // 
            this.label_intputsize.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label_intputsize.Location = new System.Drawing.Point(122, 67);
            this.label_intputsize.Name = "label_intputsize";
            this.label_intputsize.Size = new System.Drawing.Size(94, 12);
            this.label_intputsize.TabIndex = 13;
            this.label_intputsize.Text = "4096";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(7, 67);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(119, 12);
            this.label81.TabIndex = 12;
            this.label81.Text = "输入数据大小(Byte):";
            // 
            // label_outfilename
            // 
            this.label_outfilename.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label_outfilename.Location = new System.Drawing.Point(85, 44);
            this.label_outfilename.Name = "label_outfilename";
            this.label_outfilename.Size = new System.Drawing.Size(660, 12);
            this.label_outfilename.TabIndex = 9;
            this.label_outfilename.Text = "syd_arr_ok.txt";
            // 
            // source_file_button
            // 
            this.source_file_button.Location = new System.Drawing.Point(6, 18);
            this.source_file_button.Name = "source_file_button";
            this.source_file_button.Size = new System.Drawing.Size(73, 22);
            this.source_file_button.TabIndex = 6;
            this.source_file_button.Text = "选择文件";
            this.source_file_button.UseVisualStyleBackColor = true;
            this.source_file_button.Click += new System.EventHandler(this.source_file_button_Click);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(7, 44);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(83, 12);
            this.label83.TabIndex = 8;
            this.label83.Text = "输出文件名称:";
            // 
            // source_file_textBox
            // 
            this.source_file_textBox.AllowDrop = true;
            this.source_file_textBox.Location = new System.Drawing.Point(85, 19);
            this.source_file_textBox.Name = "source_file_textBox";
            this.source_file_textBox.Size = new System.Drawing.Size(660, 21);
            this.source_file_textBox.TabIndex = 7;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 582);
            this.Controls.Add(this.timer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "SYD_Calculator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.timer.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_interface)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_lock)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.LED_Display.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TabControl timer;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage LED_Display;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox LED_result1_textBox;
        private System.Windows.Forms.TextBox LED_input1_textBox;
        private System.Windows.Forms.Label label_turn1;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox_GPIO7;
        private System.Windows.Forms.TextBox textBox_GPIO6;
        private System.Windows.Forms.TextBox textBox_GPIO5;
        private System.Windows.Forms.TextBox textBox_GPIO4;
        private System.Windows.Forms.TextBox textBox_GPIO3;
        private System.Windows.Forms.TextBox textBox_GPIO2;
        private System.Windows.Forms.TextBox textBox_GPIO1;
        private System.Windows.Forms.TextBox textBox_GPIO0;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox bit_mask_result;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBoxB;
        private System.Windows.Forms.Button buttonRGB;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBoxR;
        private System.Windows.Forms.TextBox textBoxG;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox_outsidew;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox textBox_insidew;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox_outsideh;
        private System.Windows.Forms.TextBox textBox_insideh;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox_Num8;
        private System.Windows.Forms.Button button_font8;
        private System.Windows.Forms.TextBox textBox_Num7;
        private System.Windows.Forms.TextBox textBox_Hight8;
        private System.Windows.Forms.TextBox textBox_Num6;
        private System.Windows.Forms.TextBox textBox_Num5;
        private System.Windows.Forms.TextBox textBox_Width8;
        private System.Windows.Forms.TextBox textBox_Num4;
        private System.Windows.Forms.Button button_font7;
        private System.Windows.Forms.TextBox textBox_Num3;
        private System.Windows.Forms.TextBox textBox_Hight7;
        private System.Windows.Forms.TextBox textBox_Num2;
        private System.Windows.Forms.TextBox textBox_Width7;
        private System.Windows.Forms.TextBox textBox_Num1;
        private System.Windows.Forms.Button button_font6;
        private System.Windows.Forms.TextBox textBox_Hight6;
        private System.Windows.Forms.TextBox textBox_Width6;
        private System.Windows.Forms.Button button_font5;
        private System.Windows.Forms.TextBox textBox_Hight5;
        private System.Windows.Forms.TextBox textBox_Width5;
        private System.Windows.Forms.Button button_font4;
        private System.Windows.Forms.TextBox textBox_Hight4;
        private System.Windows.Forms.TextBox textBox_Width4;
        private System.Windows.Forms.Button button_font3;
        private System.Windows.Forms.TextBox textBox_Hight3;
        private System.Windows.Forms.TextBox textBox_Width3;
        private System.Windows.Forms.Button button_font2;
        private System.Windows.Forms.TextBox textBox_Hight2;
        private System.Windows.Forms.TextBox textBox_Width2;
        private System.Windows.Forms.Button button_font1;
        private System.Windows.Forms.TextBox textBox_Hight1;
        private System.Windows.Forms.TextBox textBox_Width1;
        private System.Windows.Forms.TextBox textBox_insideRw;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.TextBox textBox_insideRh;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBoxy1;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.TextBox textBoxx1;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.CheckBox BIT_MARK8;
        private System.Windows.Forms.CheckBox BIT_MARK11;
        private System.Windows.Forms.CheckBox BIT_MARK10;
        private System.Windows.Forms.CheckBox BIT_MARK9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.CheckBox BIT_MARK4;
        private System.Windows.Forms.CheckBox BIT_MARK7;
        private System.Windows.Forms.CheckBox BIT_MARK6;
        private System.Windows.Forms.CheckBox BIT_MARK5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox BIT_MARK28;
        private System.Windows.Forms.CheckBox BIT_MARK31;
        private System.Windows.Forms.CheckBox BIT_MARK30;
        private System.Windows.Forms.CheckBox BIT_MARK29;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.CheckBox BIT_MARK0;
        private System.Windows.Forms.CheckBox BIT_MARK3;
        private System.Windows.Forms.CheckBox BIT_MARK2;
        private System.Windows.Forms.CheckBox BIT_MARK1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox BIT_MARK27;
        private System.Windows.Forms.CheckBox BIT_MARK26;
        private System.Windows.Forms.CheckBox BIT_MARK25;
        private System.Windows.Forms.CheckBox BIT_MARK24;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.CheckBox BIT_MARK12;
        private System.Windows.Forms.CheckBox BIT_MARK15;
        private System.Windows.Forms.CheckBox BIT_MARK14;
        private System.Windows.Forms.CheckBox BIT_MARK13;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.CheckBox BIT_MARK16;
        private System.Windows.Forms.CheckBox BIT_MARK19;
        private System.Windows.Forms.CheckBox BIT_MARK18;
        private System.Windows.Forms.CheckBox BIT_MARK17;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.CheckBox BIT_MARK23;
        private System.Windows.Forms.CheckBox BIT_MARK22;
        private System.Windows.Forms.CheckBox BIT_MARK21;
        private System.Windows.Forms.CheckBox BIT_MARK20;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RichTextBox richTextBox_out;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.RichTextBox textInput;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.ComboBox comboBox_mode;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button draw;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.ComboBox comboBox_fonttype;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox comboBox_datatype;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox textBox_filesize;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label_intputsize;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label_outfilename;
        private System.Windows.Forms.Button source_file_button;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.TextBox source_file_textBox;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.CheckBox checkBox_synccopy;
        private System.Windows.Forms.PictureBox pictureBox_lock;
        private System.Windows.Forms.Label label_nowtime;
        private System.Windows.Forms.Button source_copyfile_button;
        private System.Windows.Forms.Button destination_file_button;
        private System.Windows.Forms.Button button_copy_sourcefile_all;
        private System.Windows.Forms.TextBox source_copyfile_textBox;
        private System.Windows.Forms.Button button_copy_destinationfile;
        private System.Windows.Forms.TextBox destination_file_textBox;
        private System.Windows.Forms.Button button_copy_sourcefile;
        private System.Windows.Forms.TextBox destination_file_textBox_two;
        private System.Windows.Forms.TextBox textBox_copy_destinationfileend;
        private System.Windows.Forms.Button destination_file_button_copy_sourcefile;
        private System.Windows.Forms.Button button_copy_destinationfileend;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.CheckBox checkBox_synccopy_sync;
        private System.Windows.Forms.Button source_copyfile_button_sync;
        private System.Windows.Forms.Button destination_file_button_sync;
        private System.Windows.Forms.Button button_copy_sourcefile_all_sync;
        private System.Windows.Forms.TextBox source_copyfile_textBox_sync;
        private System.Windows.Forms.Button button_copy_destinationfile_sync;
        private System.Windows.Forms.TextBox destination_file_textBox_sync;
        private System.Windows.Forms.Button button_copy_sourcefile_sync;
        private System.Windows.Forms.TextBox destination_file_textBox_two_sync;
        private System.Windows.Forms.TextBox textBox_copy_destinationfileend_sync;
        private System.Windows.Forms.Button destination_file_button_copy_sourcefile_sync;
        private System.Windows.Forms.Button button_copy_destinationfileend_sync;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.CheckBox checkBox_systemtime_rename;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.ComboBox comboBox_timetype_rename;
        private System.Windows.Forms.Button button_copy_sourcefile4;
        private System.Windows.Forms.Button destination_file_button_generate_rename;
        private System.Windows.Forms.TextBox source_copyfile_suffix_textBox_rename;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox source_copyfile_prefix_textBox_rename;
        private System.Windows.Forms.Button source_copyfile_button_rename;
        private System.Windows.Forms.TextBox source_copyfile_textBox_rename;
        private System.Windows.Forms.TextBox destination_file_textBox_rename;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button button_copy_sourcefile5;
        private System.Windows.Forms.Button button_splitbinfile;
        private System.Windows.Forms.TextBox textBox_splitbinfile;
        private System.Windows.Forms.TextBox textBox_section1;
        private System.Windows.Forms.ComboBox comboBox_splittype;
        private System.Windows.Forms.TextBox textBox_sectionout6;
        private System.Windows.Forms.TextBox textBox_sectionout5;
        private System.Windows.Forms.TextBox textBox_sectionout4;
        private System.Windows.Forms.TextBox textBox_sectionout3;
        private System.Windows.Forms.TextBox textBox_sectionout2;
        private System.Windows.Forms.TextBox textBox_sectionout1;
        private System.Windows.Forms.Button button_split;
        private System.Windows.Forms.TextBox textBox_section5;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox textBox_section4;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox textBox_section3;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox textBox_section2;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button button_sectionintput6;
        private System.Windows.Forms.TextBox textBox_sectionintput6;
        private System.Windows.Forms.Button button_sectionintput1;
        private System.Windows.Forms.Button button_sectionintput5;
        private System.Windows.Forms.TextBox textBox_sectionintput1;
        private System.Windows.Forms.TextBox textBox_sectionintput5;
        private System.Windows.Forms.Button button_sectionintput2;
        private System.Windows.Forms.Button button_sectionintput4;
        private System.Windows.Forms.TextBox textBox_sectionintput2;
        private System.Windows.Forms.TextBox textBox_sectionintput4;
        private System.Windows.Forms.Button button_sectionintput3;
        private System.Windows.Forms.TextBox textBox_sectionintput3;
        private System.Windows.Forms.Label label_nowtime1;
        private System.Windows.Forms.Button button_combine;
        private System.Windows.Forms.Label label_nowtime2;
        private System.Windows.Forms.Label label_nowtime4;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label_nowtime3;
        private System.Windows.Forms.Label label_nowtime0;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label_copy_time;
        private System.Windows.Forms.PictureBox pictureBox_interface;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.TextBox source_copyfile_textBox_sync_checksum;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox source_copyfile_textBox_sync_size;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_Common_path;
    }
}

